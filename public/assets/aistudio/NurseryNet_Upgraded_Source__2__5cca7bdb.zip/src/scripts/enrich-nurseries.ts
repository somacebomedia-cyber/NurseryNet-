/**
 * NurseryNet - AI Data Enrichment & Hygiene Pipeline
 * Path: src/scripts/enrich-nurseries.ts
 *
 * Port of the original MD spec, adapted to the real database:
 *  1. filterRawNurseries()  - data hygiene gate (drop closed/inactive listings
 *     when re-importing scraped Google Maps data)
 *  2. generateAIEnrichmentPrompt() - LLM prompt generator for the 12 attributes
 *     (fill ONLY fields that are null - never overwrite official data)
 *  3. applyEnrichment()     - write enriched attributes back with provenance
 *
 * Usage: bun run src/scripts/enrich-nurseries.ts <slug>   (dry-run prints prompt)
 * The actual crawl+LLM loop runs server-side where an LLM API key is available.
 */
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

export interface RawScrapedBusiness {
  placeId: string;
  title: string;
  address: string;
  city: string;
  province: string;
  phone: string;
  website?: string;
  totalScore: number;
  reviewsCount: number;
  isPermanentlyClosed: boolean;
  lastActivityDate?: string;
  rawWebsiteText?: string;
}

/**
 * Gate 2: Data Hygiene Filter
 * Drops permanently closed, 0-review, or >12-months-inactive listings.
 */
export function filterRawNurseries(rawListings: RawScrapedBusiness[]): RawScrapedBusiness[] {
  const oneYearAgo = new Date();
  oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

  return rawListings.filter((biz) => {
    if (biz.isPermanentlyClosed) return false;
    if (biz.reviewsCount <= 0) return false;
    if (biz.lastActivityDate) {
      const lastActive = new Date(biz.lastActivityDate);
      if (lastActive < oneYearAgo) return false;
    }
    return true;
  });
}

/**
 * AI Enrichment Prompt Generator for LLMs.
 * Instructs the model to answer ONLY from crawled website text and mark
 * unknowns as null - no guessing.
 */
export function generateAIEnrichmentPrompt(businessName: string, scrapedText: string): string {
  return `
You are an expert Early Childhood Education auditor for NurseryNet.
Analyze the following crawled text from the website of "${businessName}" and extract
answers to our 12 parent-centric attributes. Use ONLY evidence found in the text.
If the text does not mention an attribute, set it to null - NEVER guess.

CRAWLED WEBSITE CONTENT:
"""
${scrapedText}
"""

Return ONLY a JSON object matching this structure:
{
  "ageGroups": ["Infant (0-2 yrs)" | "Toddler (2-4 yrs)" | "Preschool (4-6 yrs)"] | null,
  "operatingModel": "Half-day (till 13:00)" | "Half-day (till 14:00)" | "Full-day (till 17:30)" | "Aftercare / Extended" | null,
  "openingTime": "HH:MM" | null,
  "closingTime": "HH:MM" | null,
  "mealsProvided": true | false | null,
  "dietaryOptions": ["Halal" | "Kosher" | "Vegetarian" | "Allergy-Safe"] | null,
  "monthlyFeeMin": number | null,
  "monthlyFeeMax": number | null,
  "subsidiesAccepted": true | false | null,
  "registrationDeposit": number | null,
  "teacherChildRatio": "string" | null,
  "firstAidCertifiedStaff": true | false | null,
  "cctvParentAccess": true | false | null,
  "securityFenceGate": true | false | null,
  "biometricAccess": true | false | null,
  "shadedPlayground": true | false | null,
  "splashPool": true | false | null,
  "extracurriculars": ["Swimming" | "Music" | "Gymnastics" | "Robotics/Coding" | "Computers" | "Art"] | null,
  "curriculum": "Play-based" | "Montessori" | "CAPS (South Africa)" | "Waldorf" | "Reggio Emilia" | "Other / General" | null,
  "primaryLanguage": "string" | null,
  "transportAvailable": true | false | null
}
`;
}

/**
 * Apply enrichment to a nursery record. Only fills NULL fields - official
 * DSD/DBE data is never overwritten by web-scraped values.
 */
export async function applyEnrichment(
  slug: string,
  enriched: Record<string, unknown>,
  source = 'ai-enriched'
) {
  const nursery = await db.nursery.findUnique({ where: { slug } });
  if (!nursery) throw new Error(`Nursery ${slug} not found`);

  const data: Record<string, unknown> = {};
  const strFields = ['openingTime', 'closingTime', 'operatingModel', 'curriculum'];
  for (const f of strFields) {
    if (enriched[f] != null && nursery[f as keyof typeof nursery] == null) {
      data[f] = enriched[f];
    }
  }
  const numFields = ['monthlyFeeMin', 'monthlyFeeMax'];
  for (const f of numFields) {
    if (typeof enriched[f] === 'number' && nursery[f as keyof typeof nursery] == null) {
      data[f] = enriched[f];
    }
  }
  const boolFields = ['mealsProvided', 'subsidiesAccepted'];
  for (const f of boolFields) {
    if (typeof enriched[f] === 'boolean' && nursery[f as keyof typeof nursery] == null) {
      data[f] = enriched[f];
    }
  }

  if (!Object.keys(data).length) return { updated: 0 };

  const sources = [...new Set([...JSON.parse(nursery.sources), source])];
  const completeness = Math.min(
    12,
    nursery.dataCompleteness +
      Object.keys(data).filter((k) => k !== 'sources').length
  );

  await db.nursery.update({
    where: { slug },
    data: {
      ...data,
      sources: JSON.stringify(sources),
      dataCompleteness: completeness,
      verificationStatus:
        nursery.verificationStatus === 'Unverified' ? 'Registered' : nursery.verificationStatus,
    },
  });
  return { updated: Object.keys(data).length };
}

// CLI: bun run src/scripts/enrich-nurseries.ts <slug>
if (import.meta.main) {
  const slug = process.argv[2];
  if (!slug) {
    console.log('Usage: bun run src/scripts/enrich-nurseries.ts <nursery-slug>');
    console.log('Prints an enrichment prompt for the given listing (pipeline dry-run).');
    process.exit(0);
  }
  const n = await db.nursery.findUnique({ where: { slug } });
  if (!n) {
    console.error('Not found:', slug);
    process.exit(1);
  }
  console.log(generateAIEnrichmentPrompt(n.name, '<crawl the website listed on this profile>'));
  await db.$disconnect();
}
