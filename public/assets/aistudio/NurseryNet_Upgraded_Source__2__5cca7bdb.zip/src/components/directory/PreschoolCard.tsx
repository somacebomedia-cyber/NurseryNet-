'use client';

/**
 * NurseryNet - Preschool Result Card
 * Displays a real ECD centre listing. Since government-sourced listings do not
 * carry photos, we use a branded gradient cover with the centre's initial -
 * no stock-photo deception.
 */
import { Nursery } from '@/types/nursery';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  MapPin,
  Phone,
  Clock,
  Users,
  Utensils,
  BadgeCheck,
  Calendar,
  ArrowRight,
  Landmark,
  CircleDollarSign,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

interface PreschoolCardProps {
  preschool: Nursery;
  onSelect: (preschool: Nursery) => void;
  onBookTour: (preschool: Nursery) => void;
}

const GRADIENTS = [
  'from-violet-500 via-purple-500 to-fuchsia-400',
  'from-purple-600 via-indigo-500 to-sky-400',
  'from-fuchsia-500 via-pink-500 to-orange-400',
  'from-indigo-500 via-violet-500 to-purple-400',
  'from-sky-500 via-violet-500 to-purple-500',
];

function verificationBadge(s: Nursery) {
  switch (s.verificationStatus) {
    case 'Verified-Pro':
      return { label: 'Verified Pro', cls: 'bg-amber-100 text-amber-800 border-amber-300' };
    case 'Owner-Claimed':
      return { label: 'Owner Claimed', cls: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    case 'Registered':
      return { label: 'Registered ECD', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    default:
      return { label: 'Unverified listing', cls: 'bg-slate-100 text-slate-600 border-slate-300' };
  }
}

export default function PreschoolCard({ preschool, onSelect, onBookTour }: PreschoolCardProps) {
  const p = preschool;
  const grad = GRADIENTS[p.name.charCodeAt(0) % GRADIENTS.length];
  const vb = verificationBadge(p);
  const feeLabel =
    p.monthlyFeeMin != null
      ? p.monthlyFeeMax && p.monthlyFeeMax !== p.monthlyFeeMin
        ? `R${p.monthlyFeeMin.toLocaleString()}–R${p.monthlyFeeMax.toLocaleString()}`
        : `R${p.monthlyFeeMin.toLocaleString()}+`
      : 'Fees on request';

  return (
    <article className="group flex flex-col bg-card rounded-2xl border border-border/80 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden hover:border-primary/40">
      {/* Branded gradient cover */}
      <button
        onClick={() => onSelect(p)}
        className={`relative h-28 w-full bg-gradient-to-br ${grad} flex items-center justify-center overflow-hidden`}
        aria-label={`View ${p.name} details`}
      >
        <span className="font-heading text-5xl font-bold text-white/95 drop-shadow-md">
          {p.name.charAt(0).toUpperCase()}
        </span>
        <span className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.35),_transparent_60%)] pointer-events-none" />
        {p.isFeatured && (
          <span className="absolute top-3 right-3 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/95 text-amber-950 shadow">
            <Sparkles className="w-3 h-3" /> Featured
          </span>
        )}
        <span className={`absolute bottom-3 left-3 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border backdrop-blur-md ${vb.cls}`}>
          <BadgeCheck className="w-3 h-3" />
          {vb.label}
        </span>
      </button>

      {/* Body */}
      <div className="p-4 flex flex-col flex-grow">
        <button onClick={() => onSelect(p)} className="text-left w-full">
          <h3 className="font-heading text-base font-bold text-foreground group-hover:text-primary transition-colors line-clamp-1">
            {p.name}
          </h3>
        </button>
        <p className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
          <MapPin className="w-3.5 h-3.5 text-accent shrink-0" />
          <span className="line-clamp-1">
            {[p.suburb, p.city].filter(Boolean).join(', ')}
          </span>
        </p>

        {/* Attribute chips - only real data */}
        <div className="flex flex-wrap gap-1.5 mt-3 min-h-[26px]">
          {p.registrationStatus && (
            <Badge variant="outline" className="text-[10px] px-2 py-0 h-5 font-semibold border-emerald-200 text-emerald-700 bg-emerald-50">
              <Landmark className="w-3 h-3 mr-1" />
              {p.registrationStatus}
            </Badge>
          )}
          {p.mealsProvided && (
            <Badge variant="outline" className="text-[10px] px-2 py-0 h-5 font-semibold">
              <Utensils className="w-3 h-3 mr-1" /> Meals
            </Badge>
          )}
          {p.operatingModel && (
            <Badge variant="outline" className="text-[10px] px-2 py-0 h-5 font-semibold">
              <Clock className="w-3 h-3 mr-1" /> {p.operatingModel.replace(' (', ' · ')}
            </Badge>
          )}
          {p.totalChildren != null && (
            <Badge variant="outline" className="text-[10px] px-2 py-0 h-5 font-semibold">
              <Users className="w-3 h-3 mr-1" /> {p.totalChildren} children
            </Badge>
          )}
          {p.curriculum && (
            <Badge variant="outline" className="text-[10px] px-2 py-0 h-5 font-semibold">
              {p.curriculum}
            </Badge>
          )}
        </div>

        {/* Footer: fee + actions */}
        <div className="mt-auto pt-3 border-t border-border/60 flex items-center justify-between gap-2 mt-3">
          <div>
            <span className="flex items-center text-[10px] text-muted-foreground">
              <CircleDollarSign className="w-3 h-3 mr-1" /> Monthly fee
            </span>
            <span className="text-sm font-extrabold text-foreground tabular-nums">{feeLabel}</span>
          </div>
          <div className="flex items-center gap-1.5">
            {p.phone ? (
              <a
                href={`tel:${p.phone}`}
                className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-border hover:border-primary hover:text-primary transition-colors"
                aria-label={`Call ${p.name}`}
                title={p.phone}
              >
                <Phone className="w-4 h-4" />
              </a>
            ) : null}
            <Button
              size="sm"
              onClick={() => onBookTour(p)}
              className="text-xs font-bold h-9 px-3.5 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 shadow-md flex items-center gap-1.5"
            >
              <Calendar className="w-3.5 h-3.5" />
              Book Tour
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}
