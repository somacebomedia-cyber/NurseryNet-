'use client';

/**
 * NurseryNet - Filter Drawer (12 parent-centric criteria)
 * Path: src/components/directory/PreschoolFilterDrawer.tsx
 *
 * Implements the MD spec's slide-over drawer. Filter options reflect what the
 * official data actually supports; unavailable attributes are never faked.
 */
import React from 'react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { SlidersHorizontal, RotateCcw, Utensils, Landmark, Phone, HandCoins } from 'lucide-react';
import { PROVINCES } from '@/types/nursery';

export interface FilterState {
  province: string;
  city: string;
  curriculum: string;
  operatingModel: string;
  maxMonthlyFee: number | null;
  meals: boolean;
  subsidy: boolean;
  registered: boolean;
  hasPhone: boolean;
}

export const DEFAULT_FILTERS: FilterState = {
  province: 'all',
  city: 'all',
  curriculum: 'all',
  operatingModel: 'all',
  maxMonthlyFee: null,
  meals: false,
  subsidy: false,
  registered: false,
  hasPhone: false,
};

const CURRICULA = ['Montessori', 'Waldorf', 'Reggio Emilia', 'Play-based'];
const OPERATING_MODELS = [
  'Half-day (till 13:00)',
  'Half-day (till 14:00)',
  'Full-day (till 17:30)',
];

interface PreschoolFilterDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onApplyFilters: (filters: FilterState) => void;
  cities: { key: string; count: number }[];
  totalResults: number;
}

export function PreschoolFilterDrawer({
  isOpen,
  onClose,
  filters,
  onApplyFilters,
  cities,
  totalResults,
}: PreschoolFilterDrawerProps) {
  const [local, setLocal] = React.useState<FilterState>(filters);

  React.useEffect(() => setLocal(filters), [filters]);

  const set = (patch: Partial<FilterState>) => setLocal((prev) => ({ ...prev, ...patch }));

  const handleApply = () => {
    onApplyFilters(local);
    onClose();
  };

  const handleReset = () => {
    setLocal(DEFAULT_FILTERS);
    onApplyFilters(DEFAULT_FILTERS);
  };

  const toggles = [
    {
      key: 'meals' as const,
      label: 'On-site meals provided',
      icon: Utensils,
      hint: 'Confirmed by DSD survey data',
    },
    {
      key: 'subsidy' as const,
      label: 'Accepts ECD subsidy',
      icon: HandCoins,
      hint: 'Government-subsidised places',
    },
    {
      key: 'registered' as const,
      label: 'Registered centres only',
      icon: Landmark,
      hint: 'DSD/DBE registration on record',
    },
    {
      key: 'hasPhone' as const,
      label: 'Has contact number',
      icon: Phone,
      hint: 'Phone number on file',
    },
  ];

  return (
    <Sheet open={isOpen} onOpenChange={(o) => (o ? null : onClose())}>
      <SheetContent side="right" className="w-full max-w-md overflow-y-auto p-0 bg-card">
        <SheetHeader className="p-5 bg-purple-blue-gradient text-white rounded-l-none">
          <SheetTitle className="font-heading text-lg font-bold text-white flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4" />
            Filter Preschools
          </SheetTitle>
          <p className="text-xs text-white/85">
            Refine by parent-centric criteria - all filters use official source data
          </p>
        </SheetHeader>

        <div className="p-5 space-y-6">
          {/* Province */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider block mb-2">Province</label>
            <Select value={local.province} onValueChange={(v) => set({ province: v, city: 'all' })}>
              <SelectTrigger className="h-10 text-sm">
                <SelectValue placeholder="All provinces" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="all">All provinces (9)</SelectItem>
                {PROVINCES.map((p) => (
                  <SelectItem key={p} value={p}>
                    {p}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* City */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider block mb-2">City / Town</label>
            <Select
              value={local.city}
              onValueChange={(v) => set({ city: v })}
              disabled={!cities.length && local.province === 'all'}
            >
              <SelectTrigger className="h-10 text-sm">
                <SelectValue placeholder="All cities & towns" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="all">All cities & towns</SelectItem>
                {cities.slice(0, 100).map((c) => (
                  <SelectItem key={c.key} value={c.key}>
                    {c.key} ({c.count})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Max fee */}
          <div>
            <div className="flex justify-between items-baseline mb-2">
              <label className="text-xs font-bold uppercase tracking-wider">Max Monthly Fee</label>
              <span className="text-xs font-extrabold text-primary tabular-nums">
                {local.maxMonthlyFee ? `R ${local.maxMonthlyFee.toLocaleString()}` : 'Any'}
              </span>
            </div>
            <Slider
              min={0}
              max={3000}
              step={100}
              value={[local.maxMonthlyFee ?? 3000]}
              onValueChange={(v) => set({ maxMonthlyFee: v[0] >= 3000 ? null : v[0] })}
            />
            <div className="flex justify-between text-[10px] text-muted-foreground mt-1 tabular-nums">
              <span>Any</span>
              <span>R1,500</span>
              <span>R3,000+</span>
            </div>
          </div>

          {/* Curriculum */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider block mb-2">Curriculum</label>
            <Select value={local.curriculum} onValueChange={(v) => set({ curriculum: v })}>
              <SelectTrigger className="h-10 text-sm">
                <SelectValue placeholder="Any curriculum" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any curriculum</SelectItem>
                {CURRICULA.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Operating model */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider block mb-2">Care Schedule</label>
            <Select value={local.operatingModel} onValueChange={(v) => set({ operatingModel: v })}>
              <SelectTrigger className="h-10 text-sm">
                <SelectValue placeholder="Any schedule" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any schedule</SelectItem>
                {OPERATING_MODELS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Toggle criteria */}
          <div className="space-y-3 pt-2 border-t border-border">
            <label className="text-xs font-bold uppercase tracking-wider block pt-2">
              Key Criteria
            </label>
            {toggles.map((t) => (
              <label
                key={t.key}
                className="flex items-center justify-between p-3 rounded-lg border border-border bg-background cursor-pointer hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <t.icon className="w-4 h-4 text-primary mt-0.5" />
                  <div>
                    <span className="text-sm font-semibold block leading-tight">{t.label}</span>
                    <span className="text-[11px] text-muted-foreground">{t.hint}</span>
                  </div>
                </div>
                <Switch checked={local[t.key]} onCheckedChange={(v) => set({ [t.key]: v } as Partial<FilterState>)} />
              </label>
            ))}
          </div>
        </div>

        <div className="p-4 border-t border-border bg-muted/40 flex gap-3 sticky bottom-0">
          <Button
            type="button"
            variant="outline"
            onClick={handleReset}
            className="w-1/3 py-3 text-xs font-semibold"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" /> Reset
          </Button>
          <Button
            type="button"
            onClick={handleApply}
            className="w-2/3 py-3 text-xs font-bold bg-primary hover:bg-primary/90"
          >
            Show {totalResults.toLocaleString()} Results
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
