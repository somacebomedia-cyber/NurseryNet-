'use client';

/**
 * NurseryNet - Owner Claim Dialog
 * First step of listing ownership verification (POST /api/claim).
 */
import { useState } from 'react';
import { Nursery } from '@/types/nursery';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { BadgeCheck, Loader2, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ClaimDialogProps {
  preschool: Nursery | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ClaimDialog({ preschool, isOpen, onClose }: ClaimDialogProps) {
  const { toast } = useToast();
  const [ownerName, setOwnerName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('Owner / Principal');
  const [proofNotes, setProofNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  if (!preschool) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nurserySlug: preschool.slug,
          ownerName,
          ownerEmail: email,
          ownerPhone: phone,
          role,
          proofNotes,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        setIsSent(true);
      } else if (res.status === 409) {
        toast({ title: 'Already claimed', description: data.error, variant: 'destructive' });
      } else {
        toast({ title: 'Could not submit', description: data.error || 'Try again shortly.', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Network error', description: 'Please try again.', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const close = () => {
    onClose();
    setTimeout(() => {
      setIsSent(false);
      setOwnerName(''); setEmail(''); setPhone(''); setProofNotes('');
    }, 300);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(o) => (o ? null : close())}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl font-bold flex items-center gap-2">
            <BadgeCheck className="w-5 h-5 text-primary" />
            {isSent ? 'Claim Submitted' : `Claim ${preschool.name}`}
          </DialogTitle>
          <DialogDescription>
            {isSent
              ? 'Our team reviews claims within 2 working days.'
              : 'Verify ownership to update fees, hours, photos and respond to parents.'}
          </DialogDescription>
        </DialogHeader>

        {isSent ? (
          <div className="py-6 text-center space-y-3">
            <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
            <p className="text-sm text-muted-foreground">
              Claim request for <strong className="text-foreground">{preschool.name}</strong> received.
              We&apos;ll contact you at <strong className="text-foreground">{email}</strong> to verify.
            </p>
            <Button onClick={close} className="font-bold bg-primary hover:bg-primary/90">Done</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="cl-name" className="text-xs font-bold">Your name</Label>
                <Input id="cl-name" required value={ownerName} onChange={(e) => setOwnerName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold">Your role</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Owner / Principal', 'Manager', 'Administrator', 'Staff member'].map((r) => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cl-email" className="text-xs font-bold">Email</Label>
              <Input id="cl-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cl-phone" className="text-xs font-bold">Phone</Label>
              <Input id="cl-phone" type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cl-proof" className="text-xs font-bold">Verification notes</Label>
              <Textarea
                id="cl-proof"
                rows={2}
                value={proofNotes}
                onChange={(e) => setProofNotes(e.target.value)}
                placeholder="e.g. DSD registration number, NPO number, or anything that helps us verify you"
              />
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full h-11 font-bold bg-primary hover:bg-primary/90">
              {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <BadgeCheck className="w-4 h-4 mr-2" />}
              {isSubmitting ? 'Submitting...' : 'Submit Claim'}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
