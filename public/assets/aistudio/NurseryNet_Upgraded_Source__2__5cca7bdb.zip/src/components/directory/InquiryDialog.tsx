'use client';

/**
 * NurseryNet - Inquiry Dialog
 * Posts to /api/inquiry. (Fixes the syntax error in the original
 * InquiryModal.tsx: `const essage, setMessage]` -> proper destructuring.)
 */
import { useState } from 'react';
import { Nursery } from '@/types/nursery';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Send, CheckCircle2, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface InquiryDialogProps {
  preschool: Nursery | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function InquiryDialog({ preschool, isOpen, onClose }: InquiryDialogProps) {
  const { toast } = useToast();
  const [parentName, setParentName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [inquiryType, setInquiryType] = useState('Fee structure & enrolment');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  if (!preschool) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName || !email) {
      toast({
        title: 'Missing information',
        description: 'Please enter your name and email address.',
        variant: 'destructive',
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nurserySlug: preschool.slug,
          nurseryName: preschool.name,
          parentName,
          parentEmail: email,
          parentPhone: phone,
          inquiryType,
          message,
        }),
      });
      if (res.ok) {
        setIsSent(true);
      } else {
        const data = await res.json().catch(() => ({}));
        toast({ title: 'Could not send inquiry', description: data.error || 'Try again shortly.', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Network error', description: 'Please try again.', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const close = () => {
    onClose();
    setTimeout(() => {
      setIsSent(false);
      setParentName(''); setEmail(''); setPhone(''); setMessage('');
    }, 300);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(o) => (o ? null : close())}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl font-bold">
            {isSent ? 'Inquiry Sent' : `Ask ${preschool.name}`}
          </DialogTitle>
          <DialogDescription>
            {isSent ? 'They will reply to your email.' : 'Fees, enrolment, waitlists - ask anything.'}
          </DialogDescription>
        </DialogHeader>

        {isSent ? (
          <div className="py-6 text-center space-y-3">
            <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
            <p className="text-sm text-muted-foreground">
              Your inquiry has been recorded. {preschool.name} will respond to{' '}
              <strong className="text-foreground">{email}</strong>.
            </p>
            <Button onClick={close} className="font-bold bg-primary hover:bg-primary/90">Done</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="space-y-1.5">
              <Label className="text-xs font-bold">What do you need?</Label>
              <Select value={inquiryType} onValueChange={setInquiryType}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[
                    'Fee structure & enrolment',
                    '2026 intake / waitlist',
                    'Daily routine & curriculum',
                    'Transport availability',
                    'Special needs support',
                    'Other',
                  ].map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="iq-name" className="text-xs font-bold">Your name</Label>
                <Input id="iq-name" required value={parentName} onChange={(e) => setParentName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="iq-phone" className="text-xs font-bold">Phone (optional)</Label>
                <Input id="iq-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="iq-email" className="text-xs font-bold">Email</Label>
              <Input id="iq-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="iq-msg" className="text-xs font-bold">Message</Label>
              <Textarea id="iq-msg" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Tell them about your child and what you're looking for..." />
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full h-11 font-bold bg-primary hover:bg-primary/90">
              {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
              {isSubmitting ? 'Sending...' : 'Send Inquiry'}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
