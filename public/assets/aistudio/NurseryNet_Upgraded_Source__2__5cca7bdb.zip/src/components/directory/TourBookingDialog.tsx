'use client';

/**
 * NurseryNet - Tour Booking Dialog
 * Posts to /api/tour-booking which persists the lead in SQLite.
 */
import { useState } from 'react';
import { Nursery } from '@/types/nursery';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar, CheckCircle2, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TourBookingDialogProps {
  preschool: Nursery | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function TourBookingDialog({ preschool, isOpen, onClose }: TourBookingDialogProps) {
  const { toast } = useToast();
  const [parentName, setParentName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [childAge, setChildAge] = useState('2-3 years');
  const [tourDate, setTourDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  });
  const [timeSlot, setTimeSlot] = useState('09:30 (Morning)');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isBooked, setIsBooked] = useState(false);

  if (!preschool) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName || !email || !phone) {
      toast({
        title: 'Required fields missing',
        description: 'Please provide your name, email and phone number.',
        variant: 'destructive',
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/tour-booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nurserySlug: preschool.slug,
          nurseryName: preschool.name,
          parentName,
          parentEmail: email,
          parentPhone: phone,
          childAge,
          preferredDate: tourDate,
          preferredSlot: timeSlot,
          notes,
        }),
      });
      if (res.ok) {
        setIsBooked(true);
      } else {
        const data = await res.json().catch(() => ({}));
        toast({
          title: 'Could not send request',
          description: data.error || 'Please try again shortly.',
          variant: 'destructive',
        });
      }
    } catch {
      toast({ title: 'Network error', description: 'Please try again.', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const close = () => {
    onClose();
    setTimeout(() => {
      setIsBooked(false);
      setParentName('');
      setEmail('');
      setPhone('');
      setNotes('');
    }, 300);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(o) => (o ? null : close())}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl font-bold">
            {isBooked ? 'Tour Request Sent' : `Book a Visit at ${preschool.name}`}
          </DialogTitle>
          <DialogDescription>
            {isBooked
              ? 'The centre will contact you to confirm.'
              : `${preschool.city}, ${preschool.province}`}
          </DialogDescription>
        </DialogHeader>

        {isBooked ? (
          <div className="py-6 text-center space-y-3">
            <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
            <p className="text-sm text-muted-foreground">
              Your tour request for <strong className="text-foreground">{preschool.name}</strong> has
              been recorded for <strong className="text-foreground">{tourDate}</strong> at{' '}
              <strong className="text-foreground">{timeSlot}</strong>. The centre will reach out to
              confirm the exact time.
            </p>
            <Button onClick={close} className="font-bold bg-primary hover:bg-primary/90">
              Done
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="tb-name" className="text-xs font-bold">Your name</Label>
                <Input id="tb-name" required value={parentName} onChange={(e) => setParentName(e.target.value)} placeholder="Parent name" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tb-child" className="text-xs font-bold">Child&apos;s age</Label>
                <Select value={childAge} onValueChange={setChildAge}>
                  <SelectTrigger id="tb-child" className="h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['0-1 years', '1-2 years', '2-3 years', '3-4 years', '4-5 years', '5-6 years'].map((a) => (
                      <SelectItem key={a} value={a}>{a}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tb-email" className="text-xs font-bold">Email</Label>
              <Input id="tb-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tb-phone" className="text-xs font-bold">Phone</Label>
              <Input id="tb-phone" type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. 082 123 4567" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="tb-date" className="text-xs font-bold">Preferred date</Label>
                <Input id="tb-date" type="date" required value={tourDate} min={new Date().toISOString().split('T')[0]} onChange={(e) => setTourDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold">Time slot</Label>
                <Select value={timeSlot} onValueChange={setTimeSlot}>
                  <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['08:00 (Morning)', '09:30 (Morning)', '11:00 (Morning)', '14:00 (Afternoon)', '15:30 (Afternoon)'].map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tb-notes" className="text-xs font-bold">Notes (optional)</Label>
              <Textarea id="tb-notes" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything the centre should know..." />
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full h-11 font-bold bg-accent text-accent-foreground hover:bg-accent/90">
              {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Calendar className="w-4 h-4 mr-2" />}
              {isSubmitting ? 'Sending...' : 'Send Tour Request'}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
