'use client';

/**
 * NurseryNet - School Profile Dialog
 * Full 12-attribute profile view with data-source attribution, claim flow,
 * tour booking and inquiry actions.
 */
import { Nursery, SOURCE_LABELS } from '@/types/nursery';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  MapPin,
  Phone,
  Mail,
  Globe,
  Clock,
  Utensils,
  Users,
  Landmark,
  Calendar,
  Send,
  HandCoins,
  BadgeCheck,
  Building2,
  FileCheck2,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';

interface SchoolDetailDialogProps {
  preschool: Nursery | null;
  isOpen: boolean;
  onClose: () => void;
  onBookTour: (p: Nursery) => void;
  onInquire: (p: Nursery) => void;
  onClaim: (p: Nursery) => void;
}

function Row({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3 py-2">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-bold">{label}</p>
        <div className="text-sm text-foreground font-semibold break-words">{value}</div>
      </div>
    </div>
  );
}

function Unknown({ label }: { label: string }) {
  return (
    <span className="text-muted-foreground font-normal">
      {label} <span className="text-xs">- contact the centre to confirm</span>
    </span>
  );
}

export default function SchoolDetailDialog({
  preschool,
  isOpen,
  onClose,
  onBookTour,
  onInquire,
  onClaim,
}: SchoolDetailDialogProps) {
  if (!preschool) return null;
  const p = preschool;

  const feeLabel =
    p.monthlyFeeMin != null
      ? p.monthlyFeeMax && p.monthlyFeeMax !== p.monthlyFeeMin
        ? `R${p.monthlyFeeMin.toLocaleString()} – R${p.monthlyFeeMax.toLocaleString()} / month`
        : `From R${p.monthlyFeeMin.toLocaleString()} / month`
      : null;

  return (
    <Dialog open={isOpen} onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent className="max-w-2xl max-h-[88vh] overflow-y-auto p-0">
        {/* Header */}
        <div className="purple-blue-gradient p-6 pt-5 text-white rounded-t-lg relative">
          <DialogHeader className="pr-8">
            <DialogTitle className="font-heading text-2xl font-bold text-white leading-tight pr-6">
              {p.name}
            </DialogTitle>
            <DialogDescription className="text-white/90 text-sm flex items-center gap-1.5 mt-1">
              <MapPin className="w-3.5 h-3.5" />
              {[p.suburb, p.city, p.province].filter(Boolean).join(', ')}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {p.verificationStatus === 'Registered' && (
              <Badge className="bg-emerald-500/90 text-white border-0 hover:bg-emerald-500">
                <Landmark className="w-3 h-3 mr-1" /> Registered ECD
              </Badge>
            )}
            {p.verificationStatus === 'Owner-Claimed' && (
              <Badge className="bg-emerald-600 text-white border-0">
                <BadgeCheck className="w-3 h-3 mr-1" /> Owner Claimed
              </Badge>
            )}
            {p.verificationStatus === 'Verified-Pro' && (
              <Badge className="bg-amber-400 text-amber-950 border-0">
                <BadgeCheck className="w-3 h-3 mr-1" /> Verified Pro
              </Badge>
            )}
            {p.emis && (
              <Badge className="bg-white/20 text-white border-white/30 border hover:bg-white/30">
                <FileCheck2 className="w-3 h-3 mr-1" /> EMIS {p.emis}
              </Badge>
            )}
            {p.siteType && <Badge className="bg-white/20 text-white border-white/30 border">{p.siteType}</Badge>}
          </div>
        </div>

        <div className="p-6 space-y-5">
          {/* Key facts grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
            <Row icon={Clock} label="Hours" value={
              p.openingTime && p.closingTime
                ? `${p.openingTime} – ${p.closingTime}${p.operatingModel ? ` (${p.operatingModel})` : ''}`
                : p.operatingModel || <Unknown label="Not on file" />
            } />
            <Row icon={Utensils} label="Meals" value={
              p.mealsProvided === true
                ? p.mealsDetail || 'Meals provided'
                : p.mealsProvided === false
                ? 'Not provided'
                : <Unknown label="Not on file" />
            } />
            <Row icon={Calendar} label="Monthly fee" value={feeLabel || <Unknown label="Fees on request" />} />
            <Row icon={HandCoins} label="ECD subsidy" value={
              p.subsidiesAccepted === true
                ? 'Subsidised places accepted'
                : p.subsidiesAccepted === false
                ? 'No subsidy places'
                : <Unknown label="Not on file" />
            } />
            <Row icon={Users} label="Enrolment" value={
              p.totalChildren != null ? `~${p.totalChildren} children enrolled (survey)` : <Unknown label="Not on file" />
            } />
            <Row icon={Building2} label="Curriculum" value={p.curriculum || <Unknown label="Not specified" />} />
          </div>

          <Separator />

          {/* Contact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
            {p.phone && <Row icon={Phone} label="Phone" value={<a className="text-primary hover:underline" href={`tel:${p.phone}`}>{p.phone}</a>} />}
            {p.address && <Row icon={MapPin} label="Address" value={p.address} />}
            {p.email && <Row icon={Mail} label="Email" value={<a className="text-primary hover:underline" href={`mailto:${p.email}`}>{p.email}</a>} />}
            {p.website && (
              <Row icon={Globe} label="Website" value={
                <a className="text-primary hover:underline inline-flex items-center gap-1" href={p.website} target="_blank" rel="noopener noreferrer">
                  Visit site <ExternalLink className="w-3 h-3" />
                </a>
              } />
            )}
          </div>

          <Separator />

          {/* Data provenance */}
          <div>
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-bold mb-2">
              Data sources
            </p>
            <div className="flex flex-wrap gap-1.5">
              {p.sources.map((s) => (
                <Badge key={s} variant="outline" className="text-[10px] font-medium">
                  {SOURCE_LABELS[s] || s}
                </Badge>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground mt-2 leading-relaxed">
              Profile completeness: {p.dataCompleteness}/12 attributes. Details not on file are shown as
              &ldquo;not on file&rdquo; - we never guess. Owners can claim this listing to add photos,
              fees and enrolment info.
            </p>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
            <Button onClick={() => onBookTour(p)} className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 font-bold h-11">
              <Calendar className="w-4 h-4 mr-2" /> Request a Tour
            </Button>
            <Button onClick={() => onInquire(p)} variant="outline" className="flex-1 font-bold h-11">
              <MessageSquare className="w-4 h-4 mr-2" /> Send Inquiry
            </Button>
          </div>
          <button
            onClick={() => onClaim(p)}
            className="w-full text-center text-xs text-muted-foreground hover:text-primary underline underline-offset-2"
          >
            Is this your centre? Claim this listing to verify and update its details
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
