'use client';

/**
 * NurseryNet - Directory Explorer
 * Client-side search UI over the server-side /api/nurseries endpoint.
 * Handles: keyword search, province pills, filter drawer, sort, pagination,
 * detail / booking / inquiry / claim dialogs.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { Nursery, NurseriesResponse, PROVINCES } from '@/types/nursery';
import PreschoolCard from './PreschoolCard';
import SchoolDetailDialog from './SchoolDetailDialog';
import TourBookingDialog from './TourBookingDialog';
import InquiryDialog from './InquiryDialog';
import ClaimDialog from './ClaimDialog';
import {
  PreschoolFilterDrawer,
  DEFAULT_FILTERS,
  FilterState,
} from './PreschoolFilterDrawer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Search,
  SlidersHorizontal,
  MapPin,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  X,
  Database,
  Loader2,
} from 'lucide-react';

type SortKey = 'relevance' | 'fee-asc' | 'fee-desc' | 'name' | 'completeness';

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'relevance', label: 'Best match' },
  { key: 'fee-asc', label: 'Fee: low to high' },
  { key: 'fee-desc', label: 'Fee: high to low' },
  { key: 'name', label: 'Name A-Z' },
  { key: 'completeness', label: 'Most complete profiles' },
];

export default function DirectoryExplorer({ initialTotal }: { initialTotal: number }) {
  const [data, setData] = useState<NurseriesResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQ, setDebouncedQ] = useState('');
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortKey>('relevance');
  const [page, setPage] = useState(1);
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Dialogs
  const [active, setActive] = useState<Nursery | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [tourOpen, setTourOpen] = useState(false);
  const [inquiryOpen, setInquiryOpen] = useState(false);
  const [claimOpen, setClaimOpen] = useState(false);

  const resultsTop = useRef<HTMLDivElement>(null);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedQ(searchQuery.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(t);
  }, [searchQuery]);

  const fetchResults = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (debouncedQ) params.set('q', debouncedQ);
    if (filters.province !== 'all') params.set('province', filters.province);
    if (filters.city !== 'all') params.set('city', filters.city);
    if (filters.curriculum !== 'all') params.set('curriculum', filters.curriculum);
    if (filters.operatingModel !== 'all') params.set('operatingModel', filters.operatingModel);
    if (filters.meals) params.set('meals', 'true');
    if (filters.subsidy) params.set('subsidy', 'true');
    if (filters.registered) params.set('registered', 'true');
    if (filters.hasPhone) params.set('hasPhone', 'true');
    if (filters.maxMonthlyFee) params.set('maxFee', String(filters.maxMonthlyFee));
    params.set('sort', sort);
    params.set('page', String(page));
    params.set('perPage', '24');
    try {
      const res = await fetch(`/api/nurseries?${params.toString()}`);
      const json = await res.json();
      if (res.ok) setData(json);
    } catch {
      // keep previous results on network blip
    } finally {
      setLoading(false);
    }
  }, [debouncedQ, filters, sort, page]);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [filters, sort]);

  const applyFilters = (f: FilterState) => {
    setFilters(f);
    setPage(1);
  };

  const hasActiveFilters = useMemo(
    () =>
      JSON.stringify(filters) !== JSON.stringify(DEFAULT_FILTERS) ||
      debouncedQ !== '' ||
      sort !== 'relevance',
    [filters, debouncedQ, sort]
  );

  const openDetail = (p: Nursery) => {
    setActive(p);
    setDetailOpen(true);
  };
  const openTour = (p: Nursery) => {
    setActive(p);
    setDetailOpen(false);
    setTourOpen(true);
  };
  const openInquiry = (p: Nursery) => {
    setActive(p);
    setDetailOpen(false);
    setInquiryOpen(true);
  };
  const openClaim = (p: Nursery) => {
    setActive(p);
    setDetailOpen(false);
    setClaimOpen(true);
  };

  const goToPage = (p: number) => {
    setPage(p);
    resultsTop.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const total = data?.total ?? initialTotal;
  const results = data?.results ?? [];
  const totalPages = data?.totalPages ?? 1;
  const cities = data?.facets?.cities ?? [];

  const provinceCounts = data?.facets?.provinces ?? [];

  return (
    <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-20">
      {/* Search & controls */}
      <div ref={resultsTop} className="pt-8 scroll-mt-20">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3.5 top-3.5" />
            <Input
              type="text"
              placeholder="Search centre name, city or suburb - e.g. Soweto, Montessori, Polokwane..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-10 py-2.5 h-12 rounded-xl bg-card shadow-sm text-sm"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-3.5 text-muted-foreground hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2.5">
            <Button
              variant="outline"
              onClick={() => setDrawerOpen(true)}
              className="h-12 px-4 rounded-xl font-bold gap-2 relative"
            >
              <SlidersHorizontal className="w-4 h-4 text-primary" />
              Filters
              {hasActiveFilters && (
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-accent border-2 border-background" />
              )}
            </Button>
            <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
              <SelectTrigger className="h-12 w-[180px] rounded-xl font-semibold text-sm bg-card shadow-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SORTS.map((s) => (
                  <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Province quick pills */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button
            onClick={() => applyFilters({ ...filters, province: 'all', city: 'all' })}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
              filters.province === 'all'
                ? 'bg-primary text-primary-foreground shadow-md scale-105'
                : 'bg-card border border-border hover:bg-muted text-foreground'
            }`}
          >
            All provinces ({initialTotal.toLocaleString()})
          </button>
          {PROVINCES.map((prov) => {
            const count = provinceCounts.find((p) => p.label === prov)?.count;
            const selected = filters.province === prov;
            return (
              <button
                key={prov}
                onClick={() => applyFilters({ ...filters, province: selected ? 'all' : prov, city: 'all' })}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all inline-flex items-center gap-1.5 ${
                  selected
                    ? 'bg-primary text-primary-foreground shadow-md scale-105'
                    : 'bg-card border border-border hover:bg-muted text-foreground'
                }`}
              >
                <MapPin className="w-3 h-3" />
                {prov}
                {count != null && <span className="opacity-70">{count.toLocaleString()}</span>}
              </button>
            );
          })}
        </div>

        {/* Status line */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-5 border-b border-border/60 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-primary" />
            {loading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin inline" />
            ) : (
              <span>
                Showing <strong className="text-foreground font-bold">{results.length}</strong> of{' '}
                <strong className="text-foreground font-bold">{total.toLocaleString()}</strong> centres
                {filters.province !== 'all' && <span> in {filters.province}</span>}
                {debouncedQ && <span> matching &ldquo;{debouncedQ}&rdquo;</span>}
              </span>
            )}
          </span>
          {hasActiveFilters && (
            <button
              onClick={() => {
                setFilters(DEFAULT_FILTERS);
                setSearchQuery('');
                setSort('relevance');
              }}
              className="text-primary hover:underline font-bold inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" /> Clear all filters
            </button>
          )}
        </div>

        {/* Results grid */}
        {loading && !results.length ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-2xl border border-border/60 overflow-hidden">
                <Skeleton className="h-28 w-full rounded-none" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-3.5 w-1/2" />
                  <Skeleton className="h-6 w-full" />
                  <div className="flex justify-between pt-3">
                    <Skeleton className="h-8 w-24" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-2xl bg-card border border-dashed border-border/80 space-y-4">
            <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center text-muted-foreground">
              <Search className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-heading text-xl font-bold">No centres match your filters</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                Try widening the fee range, clearing the city filter, or searching a different town name.
              </p>
            </div>
            <Button
              onClick={() => {
                setFilters(DEFAULT_FILTERS);
                setSearchQuery('');
              }}
              variant="outline"
              className="rounded-xl font-bold text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Reset filters
            </Button>
          </div>
        ) : (
          <div className={`grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 transition-opacity ${loading ? 'opacity-60' : ''}`}>
            {results.map((p) => (
              <PreschoolCard key={p.slug} preschool={p} onSelect={openDetail} onBookTour={openTour} />
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-10">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => goToPage(page - 1)}
              className="rounded-lg font-bold"
            >
              <ChevronLeft className="w-4 h-4" /> Prev
            </Button>
            <span className="text-sm font-semibold text-muted-foreground px-2 tabular-nums">
              Page {page} of {totalPages.toLocaleString()}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => goToPage(page + 1)}
              className="rounded-lg font-bold"
            >
              Next <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Drawer + Dialogs */}
      <PreschoolFilterDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        filters={filters}
        onApplyFilters={applyFilters}
        cities={cities}
        totalResults={total}
      />
      <SchoolDetailDialog
        preschool={active}
        isOpen={detailOpen}
        onClose={() => setDetailOpen(false)}
        onBookTour={openTour}
        onInquire={openInquiry}
        onClaim={openClaim}
      />
      <TourBookingDialog preschool={active} isOpen={tourOpen} onClose={() => setTourOpen(false)} />
      <InquiryDialog preschool={active} isOpen={inquiryOpen} onClose={() => setInquiryOpen(false)} />
      <ClaimDialog preschool={active} isOpen={claimOpen} onClose={() => setClaimOpen(false)} />
    </div>
  );
}
