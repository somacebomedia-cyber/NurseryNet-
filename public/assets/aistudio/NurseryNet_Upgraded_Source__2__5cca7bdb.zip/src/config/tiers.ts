/**
 * NurseryNet - Subscription Tier Architecture
 * Path: src/config/tiers.ts
 *
 * Monetization model for preschool listings. Free listings are sourced from
 * official government open data; paid tiers add visibility and lead routing.
 */

export interface SubscriptionTier {
  id: 'free' | 'verified' | 'pro_featured';
  name: string;
  monthlyPriceZAR: number;
  isPinnedTopSlot: boolean;
  hasVerifiedBadge: boolean;
  directLeadRouting: boolean;
  maxGalleryImages: number;
  features: string[];
}

export class TiersConfig {
  static readonly FREE: SubscriptionTier = {
    id: 'free',
    name: 'Free Listing',
    monthlyPriceZAR: 0,
    isPinnedTopSlot: false,
    hasVerifiedBadge: false,
    directLeadRouting: false,
    maxGalleryImages: 1,
    features: [
      'Basic profile from official ECD register data',
      'Appear in province & city search results',
      'Parents contact you via listed phone number',
    ],
  };

  static readonly VERIFIED: SubscriptionTier = {
    id: 'verified',
    name: 'Verified Centre',
    monthlyPriceZAR: 349,
    isPinnedTopSlot: false,
    hasVerifiedBadge: true,
    directLeadRouting: true,
    maxGalleryImages: 6,
    features: [
      'Verified badge after ownership confirmation',
      'Claim & edit your profile (fees, hours, photos)',
      'Direct lead inbox for tour requests',
      'Response-time tracking shown to parents',
    ],
  };

  static readonly PRO_FEATURED: SubscriptionTier = {
    id: 'pro_featured',
    name: 'Featured Top Slot',
    monthlyPriceZAR: 690,
    isPinnedTopSlot: true,
    hasVerifiedBadge: true,
    directLeadRouting: true,
    maxGalleryImages: 15,
    features: [
      'Everything in Verified',
      'Pinned top slot in your city search results',
      'Featured card on your city landing page',
      'Priority placement in the monthly city guide',
      'Analytics: views, leads, conversion funnel',
    ],
  };

  static all(): SubscriptionTier[] {
    return [TiersConfig.FREE, TiersConfig.VERIFIED, TiersConfig.PRO_FEATURED];
  }
}
