/**
 * NurseryNet - Directory Stats API
 * GET /api/stats
 * Aggregate counts powering the homepage trust bar & data transparency panel.
 */
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const revalidate = 3600;

export async function GET() {
  try {
    const [total, byProvince, withPhone, withFees, withGps, registered, cities] = await Promise.all([
      db.nursery.count(),
      db.nursery.groupBy({ by: ['province'], _count: { _all: true } }),
      db.nursery.count({ where: { phone: { not: null } } }),
      db.nursery.count({ where: { monthlyFeeMin: { not: null } } }),
      db.nursery.count({ where: { lat: { not: null } } }),
      db.nursery.count({ where: { verificationStatus: { in: ['Registered', 'Owner-Claimed', 'Verified-Pro'] } } }),
      db.nursery.groupBy({ by: ['city'], _count: { _all: true } }),
    ]);

    const topCities = cities
      .map((c) => ({ city: c.city, count: c._count._all }))
      .filter((c) => c.count >= 5)
      .sort((a, b) => b.count - a.count)
      .slice(0, 24);

    return NextResponse.json({
      total,
      byProvince: byProvince
        .map((p) => ({ province: p.province, count: p._count._all }))
        .sort((a, b) => b.count - a.count),
      withPhone,
      withFees,
      withGps,
      registered,
      distinctCities: new Set(cities.map((c) => c.city)).size,
      topCities,
    });
  } catch (err) {
    console.error('[/api/stats]', err);
    return NextResponse.json({ error: 'Failed to compute stats.' }, { status: 500 });
  }
}
