/**
 * NurseryNet - Tour Booking Lead Capture
 * POST /api/tour-booking
 *
 * Persists the lead in the database and (in production) would notify the
 * principal via email. Validates input server-side.
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      nurserySlug,
      nurseryName,
      parentName,
      parentEmail,
      parentPhone,
      childAge,
      preferredDate,
      preferredSlot,
      notes,
    } = body || {};

    if (!nurserySlug || !parentName || !parentEmail || !parentPhone) {
      return NextResponse.json(
        { error: 'nurserySlug, parentName, parentEmail and parentPhone are required.' },
        { status: 400 }
      );
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(parentEmail)) {
      return NextResponse.json({ error: 'Invalid email address.' }, { status: 400 });
    }

    // Verify the nursery exists (protects against spam slugs)
    const nursery = await db.nursery.findUnique({ where: { slug: nurserySlug } });
    if (!nursery) {
      return NextResponse.json({ error: 'Unknown nursery.' }, { status: 404 });
    }

    const lead = await db.tourLead.create({
      data: {
        nurserySlug,
        nurseryName: nurseryName || nursery.name,
        parentName,
        parentEmail,
        parentPhone,
        childAge: childAge || null,
        preferredDate: preferredDate || null,
        preferredSlot: preferredSlot || null,
        notes: notes || null,
      },
    });

    console.log('[TourLead captured]', {
      id: lead.id,
      nursery: nursery.name,
      city: nursery.city,
    });

    return NextResponse.json(
      { success: true, message: 'Tour request captured.', leadId: lead.id },
      { status: 201 }
    );
  } catch (err) {
    console.error('[/api/tour-booking]', err);
    return NextResponse.json({ error: 'Error saving tour lead.' }, { status: 500 });
  }
}
