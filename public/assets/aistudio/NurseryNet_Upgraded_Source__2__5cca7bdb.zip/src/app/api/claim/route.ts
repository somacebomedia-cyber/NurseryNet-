/**
 * NurseryNet - Owner Claim Request
 * POST /api/claim
 *
 * First step of the ownership verification workflow: the principal requests
 * to claim their listing. Admin approves -> verificationStatus becomes
 * 'Owner-Claimed' (and 'Verified-Pro' once subscribed).
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { nurserySlug, ownerName, ownerEmail, ownerPhone, role, proofNotes } = body || {};

    if (!nurserySlug || !ownerName || !ownerEmail || !ownerPhone) {
      return NextResponse.json(
        { error: 'nurserySlug, ownerName, ownerEmail and ownerPhone are required.' },
        { status: 400 }
      );
    }

    const nursery = await db.nursery.findUnique({ where: { slug: nurserySlug } });
    if (!nursery) {
      return NextResponse.json({ error: 'Unknown nursery.' }, { status: 404 });
    }
    if (nursery.verificationStatus === 'Owner-Claimed' || nursery.verificationStatus === 'Verified-Pro') {
      return NextResponse.json(
        { error: 'This listing has already been claimed. Contact support if this is an error.' },
        { status: 409 }
      );
    }

    const claim = await db.claimRequest.create({
      data: {
        nurserySlug,
        nurseryName: nursery.name,
        ownerName,
        ownerEmail,
        ownerPhone,
        role: role || null,
        proofNotes: proofNotes || null,
      },
    });

    return NextResponse.json(
      { success: true, claimId: claim.id, message: 'Claim request received for review.' },
      { status: 201 }
    );
  } catch (err) {
    console.error('[/api/claim]', err);
    return NextResponse.json({ error: 'Error saving claim request.' }, { status: 500 });
  }
}
