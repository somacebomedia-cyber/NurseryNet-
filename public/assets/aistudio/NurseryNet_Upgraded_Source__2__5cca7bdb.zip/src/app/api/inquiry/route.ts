/**
 * NurseryNet - General Inquiry Lead Capture
 * POST /api/inquiry
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { nurserySlug, nurseryName, parentName, parentEmail, parentPhone, inquiryType, message } =
      body || {};

    if (!nurserySlug || !parentName || !parentEmail) {
      return NextResponse.json(
        { error: 'nurserySlug, parentName and parentEmail are required.' },
        { status: 400 }
      );
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(parentEmail)) {
      return NextResponse.json({ error: 'Invalid email address.' }, { status: 400 });
    }

    const nursery = await db.nursery.findUnique({ where: { slug: nurserySlug } });
    if (!nursery) {
      return NextResponse.json({ error: 'Unknown nursery.' }, { status: 404 });
    }

    const lead = await db.inquiryLead.create({
      data: {
        nurserySlug,
        nurseryName: nurseryName || nursery.name,
        parentName,
        parentEmail,
        parentPhone: parentPhone || null,
        inquiryType: inquiryType || 'General',
        message: message || null,
      },
    });

    return NextResponse.json({ success: true, leadId: lead.id }, { status: 201 });
  } catch (err) {
    console.error('[/api/inquiry]', err);
    return NextResponse.json({ error: 'Error saving inquiry.' }, { status: 500 });
  }
}
