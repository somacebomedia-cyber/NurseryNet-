/**
 * NurseryNet - Directory Search API
 * GET /api/nurseries
 *
 * Server-side search, filter, sort & paginate over 30,000+ real ECD centres.
 * Query params: q, province, city, meals, subsidy, registered, hasPhone,
 *               minFee, maxFee, curriculum, operatingModel, page, perPage, sort
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { Prisma } from '@prisma/client';
import type { Nursery } from '@/types/nursery';

export const dynamic = 'force-dynamic';

function serializeNursery(n: {
  id: string; slug: string; name: string; province: string; city: string;
  suburb: string | null; district: string | null; lat: number | null; lon: number | null;
  address: string | null; phone: string | null; email: string | null; website: string | null;
  registrationStatus: string | null; verificationStatus: string; emis: string | null;
  mealsProvided: boolean | null; mealsDetail: string | null; monthlyFeeMin: number | null;
  monthlyFeeMax: number | null; openingTime: string | null; closingTime: string | null;
  operatingModel: string | null; subsidiesAccepted: boolean | null; totalChildren: number | null;
  siteType: string | null; curriculum: string | null; isFeatured: boolean;
  dataCompleteness: number; sources: string;
}): Nursery {
  let sources: string[] = [];
  try { sources = JSON.parse(n.sources); } catch { sources = []; }
  return { ...n, sources };
}

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const q = sp.get('q')?.trim() || undefined;
    const province = sp.get('province')?.trim() || undefined;
    const city = sp.get('city')?.trim() || undefined;
    const curriculum = sp.get('curriculum')?.trim() || undefined;
    const operatingModel = sp.get('operatingModel')?.trim() || undefined;
    const meals = sp.get('meals') === 'true';
    const subsidy = sp.get('subsidy') === 'true';
    const registered = sp.get('registered') === 'true';
    const hasPhone = sp.get('hasPhone') === 'true';
    const minFee = sp.get('minFee') ? Number(sp.get('minFee')) : undefined;
    const maxFee = sp.get('maxFee') ? Number(sp.get('maxFee')) : undefined;
    const page = Math.max(1, Number(sp.get('page')) || 1);
    const perPage = Math.min(48, Math.max(6, Number(sp.get('perPage')) || 24));
    const sort = (sp.get('sort') as 'relevance' | 'fee-asc' | 'fee-desc' | 'name' | 'completeness') || 'relevance';

    const where: Prisma.NurseryWhereInput = {};
    if (q) {
      where.OR = [
        { name: { contains: q } },
        { city: { contains: q } },
        { suburb: { contains: q } },
      ];
    }
    if (province) where.province = province;
    if (city) where.city = city;
    if (curriculum) where.curriculum = curriculum;
    if (operatingModel) where.operatingModel = operatingModel;
    if (meals) where.mealsProvided = true;
    if (subsidy) where.subsidiesAccepted = true;
    if (registered) where.verificationStatus = { in: ['Registered', 'Owner-Claimed', 'Verified-Pro'] };
    if (hasPhone) where.phone = { not: null };
    if (minFee != null || maxFee != null) {
      where.monthlyFeeMin = {};
      if (minFee != null) where.monthlyFeeMin.gte = minFee;
      if (maxFee != null) where.monthlyFeeMin.lte = maxFee;
    }

    const orderBy: Prisma.NurseryOrderByWithRelationInput[] =
      sort === 'fee-asc'
        ? [{ monthlyFeeMin: 'asc' }, { dataCompleteness: 'desc' }]
        : sort === 'fee-desc'
        ? [{ monthlyFeeMin: 'desc' }, { dataCompleteness: 'desc' }]
        : sort === 'name'
        ? [{ name: 'asc' }]
        : sort === 'completeness'
        ? [{ dataCompleteness: 'desc' }, { name: 'asc' }]
        : [{ isFeatured: 'desc' }, { dataCompleteness: 'desc' }, { name: 'asc' }];

    const [total, rows, provGroups, cityGroups] = await Promise.all([
      db.nursery.count({ where }),
      db.nursery.findMany({
        where,
        orderBy,
        skip: (page - 1) * perPage,
        take: perPage,
      }),
      db.nursery.groupBy({
        by: ['province'],
        where: {
          ...(q ? { OR: [{ name: { contains: q } }, { city: { contains: q } }, { suburb: { contains: q } }] } : {}),
        },
        _count: { _all: true },
      }),
      db.nursery.groupBy({
        by: ['city'],
        where: {
          ...(province ? { province } : {}),
          ...(q ? { OR: [{ name: { contains: q } }, { city: { contains: q } }, { suburb: { contains: q } }] } : {}),
        },
        _count: { _all: true },
      }),
    ]);

    const provinces = provGroups
      .map((g) => ({ key: g.province, label: g.province, count: g._count._all }))
      .sort((a, b) => b.count - a.count);

    const cities = cityGroups
      .map((g) => ({ key: g.city, count: g._count._all }))
      .filter((c) => c.count >= 3)
      .sort((a, b) => b.count - a.count)
      .slice(0, 60);

    return NextResponse.json({
      total,
      page,
      perPage,
      totalPages: Math.max(1, Math.ceil(total / perPage)),
      results: rows.map(serializeNursery),
      facets: { provinces, cities },
    });
  } catch (err) {
    console.error('[/api/nurseries]', err);
    return NextResponse.json({ error: 'Failed to query directory.' }, { status: 500 });
  }
}
