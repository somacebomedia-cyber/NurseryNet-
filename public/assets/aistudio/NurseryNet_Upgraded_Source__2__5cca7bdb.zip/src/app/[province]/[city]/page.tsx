/**
 * NurseryNet - City Landing Page (programmatic SEO)
 * /[province]/[city] e.g. /gauteng/pretoria
 * "Best preschools & day cares in {city}" listicle with ItemList JSON-LD.
 */
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import { PROVINCE_SLUGS } from '@/types/nursery';
import { generateItemListSchema, generateBreadcrumbSchema } from '@/lib/schema-generator';
import {
  MapPin,
  ArrowRight,
  Landmark,
  Utensils,
  HandCoins,
  Clock,
  Phone,
} from 'lucide-react';

export const revalidate = 3600;
export const dynamicParams = true;

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

async function cityFromSlug(provinceSlug: string, citySlug: string) {
  const province = PROVINCE_SLUGS[provinceSlug];
  if (!province) return null;
  // exact slug match first, then fuzzy (accents / punctuation)
  let cities = await db.nursery.findMany({
    where: { province },
    distinct: ['city'],
    select: { city: true },
  });
  const exact = cities.find((c) => slugify(c.city) === citySlug);
  if (exact) return { province, city: exact.city };
  // try decoded with spaces/case variants
  const decoded = decodeURIComponent(citySlug).replace(/-/g, ' ').toLowerCase();
  const fuzzy = cities.find((c) => c.city.toLowerCase() === decoded);
  return fuzzy ? { province, city: fuzzy.city } : null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ province: string; city: string }>;
}): Promise<Metadata> {
  const { province: pSlug, city: cSlug } = await params;
  const loc = await cityFromSlug(pSlug, cSlug);
  if (!loc) return { title: 'Not found' };
  return {
    title: `Preschools & Day Care Centres in ${loc.city}, ${loc.province} (2026 Guide)`,
    description: `Compare ${loc.city} preschools, crèches and ECD centres. Fees, DSD registration status, meals, subsidy places and daily schedule - request tours directly.`,
    alternates: { canonical: `/${pSlug}/${cSlug}` },
  };
}

export default async function CityPage({
  params,
}: {
  params: Promise<{ province: string; city: string }>;
}) {
  const { province: pSlug, city: cSlug } = await params;
  const loc = await cityFromSlug(pSlug, cSlug);
  if (!loc) notFound();
  const { province, city } = loc;

  const [total, top] = await Promise.all([
    db.nursery.count({ where: { province, city } }),
    db.nursery.findMany({
      where: { province, city },
      orderBy: [{ isFeatured: 'desc' }, { dataCompleteness: 'desc' }, { name: 'asc' }],
      take: 60,
      select: {
        slug: true, name: true, suburb: true, monthlyFeeMin: true, monthlyFeeMax: true,
        verificationStatus: true, mealsProvided: true, subsidiesAccepted: true,
        operatingModel: true, phone: true, openingTime: true, closingTime: true,
      },
    }),
  ]);

  const withMeals = top.filter((t) => t.mealsProvided).length;
  const withSubsidy = top.filter((t) => t.subsidiesAccepted).length;
  const registered = top.filter((t) => t.verificationStatus !== 'Unverified').length;

  const jsonLd = generateItemListSchema(city, province, top.slice(0, 10).map((t) => ({ slug: t.slug, name: t.name })));
  const breadcrumbs = generateBreadcrumbSchema([
    { name: 'NurseryNet', url: 'https://nursery-net.vercel.app' },
    { name: province, url: `https://nursery-net.vercel.app/${pSlug}` },
    { name: city, url: `https://nursery-net.vercel.app/${pSlug}/${cSlug}` },
  ]);

  return (
    <div className="min-h-screen flex flex-col">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }} />

      <section className="purple-blue-gradient text-white">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
          <nav className="text-xs font-bold text-yellow-300 mb-3 flex items-center gap-1.5">
            <Link href="/" className="hover:underline">Home</Link>
            <span>/</span>
            <Link href={`/${pSlug}`} className="hover:underline">{province}</Link>
          </nav>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold drop-shadow-md">
            Preschools & Day Care Centres in {city}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-white/90 max-w-2xl">
            {total.toLocaleString()} ECD centres found in {city}. Evaluate fees, registration,
            meals and subsidy places - then request a tour directly.
          </p>
          {total > 0 && (
            <div className="mt-5 flex flex-wrap gap-2 text-[11px] font-bold">
              <span className="px-2.5 py-1 rounded-full bg-white/15 border border-white/25 backdrop-blur-sm">
                <Landmark className="w-3 h-3 inline mr-1 -mt-0.5" />{registered} registered (top results)
              </span>
              <span className="px-2.5 py-1 rounded-full bg-white/15 border border-white/25 backdrop-blur-sm">
                <Utensils className="w-3 h-3 inline mr-1 -mt-0.5" />{withMeals} serve meals
              </span>
              <span className="px-2.5 py-1 rounded-full bg-white/15 border border-white/25 backdrop-blur-sm">
                <HandCoins className="w-3 h-3 inline mr-1 -mt-0.5" />{withSubsidy} accept subsidies
              </span>
            </div>
          )}
        </div>
      </section>

      <main className="flex-grow container mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
        {top.length === 0 ? (
          <p className="text-center text-muted-foreground py-12">
            No centres on file for {city} yet. <Link href="/" className="text-primary font-bold hover:underline">Search the full directory →</Link>
          </p>
        ) : (
          <ol className="space-y-3">
            {top.map((n, i) => (
              <li key={n.slug}>
                <Link
                  href={`/preschools/${n.slug}`}
                  className="group flex gap-4 bg-card border border-border/70 rounded-2xl p-4 sm:p-5 hover:border-primary/50 hover:shadow-lg transition-all"
                >
                  <div className="w-10 h-10 rounded-xl purple-blue-gradient text-white font-heading font-bold flex items-center justify-center shrink-0">
                    {i + 1}
                  </div>
                  <div className="min-w-0 flex-grow">
                    <h2 className="font-heading text-base sm:text-lg font-bold group-hover:text-primary transition-colors leading-snug">
                      {n.name}
                    </h2>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground mt-1.5">
                      {n.suburb && (
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {n.suburb}
                        </span>
                      )}
                      {n.verificationStatus !== 'Unverified' && (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                          <Landmark className="w-3 h-3" /> {n.verificationStatus === 'Registered' ? 'Registered' : n.verificationStatus}
                        </span>
                      )}
                      {n.monthlyFeeMin != null && (
                        <span className="font-bold text-foreground tabular-nums">
                          {n.monthlyFeeMax ? `R${n.monthlyFeeMin}–R${n.monthlyFeeMax}` : `from R${n.monthlyFeeMin}`}/mo
                        </span>
                      )}
                      {n.operatingModel && (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {n.operatingModel}
                        </span>
                      )}
                      {n.phone && (
                        <span className="inline-flex items-center gap-1">
                          <Phone className="w-3 h-3" /> {n.phone}
                        </span>
                      )}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0 self-center" />
                </Link>
              </li>
            ))}
          </ol>
        )}
        {total > top.length && (
          <p className="text-center text-sm text-muted-foreground mt-6">
            Showing top {top.length} of {total.toLocaleString()} centres in {city}.{' '}
            <Link href="/" className="text-primary font-bold hover:underline">
              Search all {city} centres with filters →
            </Link>
          </p>
        )}
      </main>

      <footer className="bg-foreground text-background mt-auto">
        <div className="container mx-auto max-w-7xl px-4 py-6 text-xs opacity-80 text-center">
          NurseryNet · Official-source ECD directory · {city}, {province}
        </div>
      </footer>
    </div>
  );
}
