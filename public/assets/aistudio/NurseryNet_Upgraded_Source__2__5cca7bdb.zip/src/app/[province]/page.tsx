/**
 * NurseryNet - Province Landing Page (programmatic SEO)
 * /[province] e.g. /gauteng - lists city hubs & top centres for the province.
 */
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import { PROVINCE_SLUGS } from '@/types/nursery';
import { generateBreadcrumbSchema } from '@/lib/schema-generator';
import { MapPin, ArrowRight, Database } from 'lucide-react';

export const revalidate = 3600;
export const dynamicParams = true;

export function generateStaticParams() {
  return Object.keys(PROVINCE_SLUGS).map((province) => ({ province }));
}

function titleCase(slug: string): string | null {
  const name = PROVINCE_SLUGS[slug];
  return name || null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ province: string }>;
}): Promise<Metadata> {
  const { province: slug } = await params;
  const province = titleCase(slug);
  if (!province) return { title: 'Not found' };
  return {
    title: `Preschools & Day Care Centres in ${province}`,
    description: `Browse ECD centres, crèches, nursery schools and day care centres across ${province}, South Africa. Fees, registration status, meals and subsidy data from official DSD & DBE sources.`,
    alternates: { canonical: `/${slug}` },
  };
}

export default async function ProvincePage({
  params,
}: {
  params: Promise<{ province: string }>;
}) {
  const { province: slug } = await params;
  const province = titleCase(slug);
  if (!province) notFound();

  const [total, cityGroups, top] = await Promise.all([
    db.nursery.count({ where: { province } }),
    db.nursery.groupBy({
      by: ['city'],
      where: { province },
      _count: { _all: true },
    }),
    db.nursery.findMany({
      where: { province },
      orderBy: [{ dataCompleteness: 'desc' }, { name: 'asc' }],
      take: 12,
      select: { slug: true, name: true, city: true, monthlyFeeMin: true, verificationStatus: true },
    }),
  ]);

  const cities = cityGroups
    .map((c) => ({ city: c.city, count: c._count._all }))
    .filter((c) => c.count >= 3)
    .sort((a, b) => b.count - a.count);

  const jsonLd = generateBreadcrumbSchema([
    { name: 'NurseryNet', url: 'https://nursery-net.vercel.app' },
    { name: province, url: `https://nursery-net.vercel.app/${slug}` },
  ]);

  return (
    <div className="min-h-screen flex flex-col">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <section className="purple-blue-gradient text-white">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
          <Link href="/" className="text-xs font-bold text-yellow-300 hover:underline inline-flex items-center gap-1 mb-3">
            ← All provinces
          </Link>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold drop-shadow-md">
            Preschools & Day Care Centres in {province}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-white/90 max-w-2xl">
            {total.toLocaleString()} ECD centres, crèches and nursery schools across {province},
            built from official DSD &amp; DBE records.
          </p>
        </div>
      </section>

      <main className="flex-grow container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        {/* City hubs */}
        <section>
          <h2 className="font-heading text-2xl font-bold mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" /> Browse by city or town
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {cities.map((c) => (
              <Link
                key={c.city}
                href={`/${slug}/${encodeURIComponent(c.city.toLowerCase().replace(/ /g, '-'))}`}
                className="group bg-card border border-border/70 rounded-xl px-4 py-3 hover:border-primary/50 hover:shadow-md transition-all"
              >
                <div className="font-bold text-sm group-hover:text-primary transition-colors">{c.city}</div>
                <div className="text-[11px] text-muted-foreground">{c.count} centres</div>
              </Link>
            ))}
          </div>
        </section>

        {/* Top profiles */}
        <section className="mt-12">
          <h2 className="font-heading text-2xl font-bold mb-4 flex items-center gap-2">
            <Database className="w-5 h-5 text-primary" /> Most complete profiles in {province}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {top.map((n) => (
              <Link
                key={n.slug}
                href={`/preschools/${n.slug}`}
                className="group flex items-center justify-between bg-card border border-border/70 rounded-xl px-4 py-3.5 hover:border-primary/50 hover:shadow-md transition-all"
              >
                <div className="min-w-0">
                  <div className="font-bold text-sm group-hover:text-primary transition-colors truncate">{n.name}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {n.city}
                    {n.monthlyFeeMin != null && ` · from R${n.monthlyFeeMin.toLocaleString()}/mo`}
                    {n.verificationStatus === 'Registered' && ' · Registered'}
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0 ml-3" />
              </Link>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-foreground text-background mt-auto">
        <div className="container mx-auto max-w-7xl px-4 py-6 text-xs opacity-80 text-center">
          NurseryNet · Official-source ECD directory · {province}
        </div>
      </footer>
    </div>
  );
}
