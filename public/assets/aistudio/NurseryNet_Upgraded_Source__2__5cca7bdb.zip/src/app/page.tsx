/**
 * NurseryNet - Home / Directory
 * Server component: pulls live counts from the DB for the trust bar, then
 * renders the interactive directory explorer.
 */
import Link from 'next/link';
import { db } from '@/lib/db';
import DirectoryExplorer from '@/components/directory/DirectoryExplorer';
import { PROVINCES } from '@/types/nursery';
import {
  Sparkles,
  Database,
  Landmark,
  MapPin,
  HandCoins,
  ShieldCheck,
  ArrowRight,
  Baby,
  Building2,
} from 'lucide-react';

export const dynamic = 'force-dynamic';

async function getStats() {
  try {
    const [total, registered, withFees, provCounts] = await Promise.all([
      db.nursery.count(),
      db.nursery.count({
        where: { verificationStatus: { in: ['Registered', 'Owner-Claimed', 'Verified-Pro'] } },
      }),
      db.nursery.count({ where: { monthlyFeeMin: { not: null } } }),
      db.nursery.groupBy({ by: ['province'], _count: { _all: true } }),
    ]);
    return {
      total,
      registered,
      withFees,
      byProvince: Object.fromEntries(provCounts.map((p) => [p.province, p._count._all])),
    };
  } catch {
    return { total: 0, registered: 0, withFees: 0, byProvince: {} as Record<string, number> };
  }
}

export default async function HomePage() {
  const stats = await getStats();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero */}
      <section className="purple-blue-gradient text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.2),_transparent_60%)] pointer-events-none" />
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold text-yellow-300 mb-5 border border-white/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>South Africa&apos;s largest source-verified ECD directory</span>
          </div>
          <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white drop-shadow-md">
            Find a preschool or day care
            <br className="hidden sm:block" /> anywhere in South Africa
          </h1>
          <p className="mt-5 max-w-2xl mx-auto text-base sm:text-lg text-white/95 font-medium leading-relaxed">
            {stats.total.toLocaleString()}+ real ECD centres, crèches and nursery schools across all 9
            provinces - with fees, registration status, meals and subsidy data from official DSD &amp;
            DBE sources.
          </p>

          {/* Trust bar */}
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto">
            {[
              { icon: Database, value: stats.total.toLocaleString() + '+', label: 'ECD centres listed' },
              { icon: Landmark, value: stats.registered.toLocaleString() + '+', label: 'Registered centres' },
              { icon: HandCoins, value: stats.withFees.toLocaleString() + '+', label: 'With fee data' },
              { icon: MapPin, value: '9 / 9', label: 'Provinces covered' },
            ].map((s, i) => (
              <div key={i} className="rounded-2xl bg-white/15 backdrop-blur-md border border-white/25 px-3 py-4">
                <s.icon className="w-5 h-5 text-yellow-300 mx-auto mb-1.5" />
                <div className="text-xl font-extrabold tabular-nums">{s.value}</div>
                <div className="text-[11px] text-white/85 font-semibold">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Province strip */}
      <section className="bg-card border-b border-border/60">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
            <span className="font-bold text-foreground inline-flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-primary" /> Browse by province:
            </span>
            {PROVINCES.map((p) => (
              <Link
                key={p}
                href={`/${p.toLowerCase().replace(/ /g, '-')}`}
                className="hover:text-primary font-semibold transition-colors"
              >
                {p}
                {stats.byProvince[p] ? (
                  <span className="text-muted-foreground/70 ml-1">({stats.byProvince[p].toLocaleString()})</span>
                ) : null}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Directory */}
      <main className="flex-grow">
        <DirectoryExplorer initialTotal={stats.total} />
      </main>

      {/* Data transparency */}
      <section className="bg-muted/50 border-t border-border/60">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <ShieldCheck className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Real data, honestly labelled</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Every listing is built from official government open data - the DPME/DSD national ECD
                register, DSD ECD survey, DBE registered-centre lists and the December 2024
                under-resourced ECD list. Attributes we don&apos;t have are shown as &ldquo;not on
                file&rdquo; - never guessed.
              </p>
            </div>
            <div>
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Baby className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Built for parents</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Filter by what actually matters: fees in Rand, meals, ECD subsidy places, registration
                status and daily schedule. Request tours and send inquiries directly - free, no
                sign-up required.
              </p>
            </div>
            <div>
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">For centre owners</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Is your centre listed? Claim it free to verify and update your details. Verified
                centres get a badge, a lead inbox, and an optional Featured slot in their city.
              </p>
              <Link href="#directory-top" className="text-primary text-sm font-bold hover:underline inline-flex items-center gap-1 mt-2">
                Search for your centre <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground mt-8 leading-relaxed max-w-4xl">
            Sources: DPME/DSD National ECD Register; DSD ECD Survey 2015 (via DPME spatial services);
            DBE Registered ECD Centres 2015 &amp; 2017 Q1; DBE List of Under-Resourced ECD Centres
            (Dec 2024); WCED EMIS Directory; City of Cape Town Open Data; OpenStreetMap contributors
            (ODbL). Listing data reflects the most recent available official records; enrolment and
            fee figures are historical survey values - always confirm directly with the centre.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background mt-auto">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="font-heading font-bold text-lg">Nursery<span className="text-yellow-400">Net</span></div>
          <p className="text-xs opacity-80">
            {stats.total.toLocaleString()}+ ECD centres · 9 provinces · Data from official SA government sources
          </p>
        </div>
      </footer>
    </div>
  );
}
