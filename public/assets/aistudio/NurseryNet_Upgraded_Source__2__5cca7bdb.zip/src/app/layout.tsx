import type { Metadata } from "next";
import { Fredoka, Nunito } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const fredoka = Fredoka({
  variable: "--font-fredoka",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
});

const nunito = Nunito({
  variable: "--font-nunito",
  subsets: ["latin"],
  weight: ["200", "300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: {
    default: "NurseryNet - South Africa's ECD & Preschool Directory",
    template: "%s | NurseryNet",
  },
  description:
    "Search 30,000+ real early childhood development centres, crèches, day care centres and preschools across all 9 South African provinces. Fees, registration status, meals, subsidies and more - from official DSD & DBE data.",
  keywords: [
    "preschool South Africa",
    "creche",
    "day care centre",
    "ECD centre",
    "Grade R",
    "nursery school",
    "early childhood development",
    "Montessori South Africa",
  ],
  openGraph: {
    title: "NurseryNet - South Africa's ECD & Preschool Directory",
    description:
      "30,000+ verified-source ECD centres across all 9 provinces. Fees, meals, subsidies, registration status.",
    siteName: "NurseryNet",
    type: "website",
    locale: "en_ZA",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en-ZA" suppressHydrationWarning>
      <body
        className={`${fredoka.variable} ${nunito.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
