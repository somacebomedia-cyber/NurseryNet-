/**
 * NurseryNet - Preschool Profile Page (programmatic SEO)
 * /preschools/[slug] - individual centre page with ChildCare JSON-LD.
 */
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import { SOURCE_LABELS } from '@/types/nursery';
import { generateChildCareSchema, generateBreadcrumbSchema } from '@/lib/schema-generator';
import {
  MapPin, Phone, Mail, Globe, Clock, Utensils, Users, Landmark, Calendar,
  HandCoins, BadgeCheck, Building2, ExternalLink, Send, FileCheck2,
} from 'lucide-react';

export const revalidate = 3600;
export const dynamicParams = true;

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const SITE = 'https://nursery-net.vercel.app';

async function getNursery(slug: string) {
  return db.nursery.findUnique({ where: { slug } });
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const n = await getNursery(slug);
  if (!n) return { title: 'Not found' };
  const fee = n.monthlyFeeMin ? ` · from R${n.monthlyFeeMin}/month` : '';
  return {
    title: `${n.name} - ${n.city}, ${n.province}`,
    description: `${n.name} is an early childhood development centre in ${n.city}, ${n.province}${fee}. Registration status, meals, subsidies, hours and contact details - request a tour.`,
    alternates: { canonical: `/preschools/${n.slug}` },
  };
}

export default async function PreschoolPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const n = await getNursery(slug);
  if (!n) notFound();

  let sources: string[] = [];
  try { sources = JSON.parse(n.sources); } catch { /* noop */ }

  const jsonLd = generateChildCareSchema(n);
  const breadcrumbs = generateBreadcrumbSchema([
    { name: 'NurseryNet', url: SITE },
    { name: n.province, url: `${SITE}/${slugify(n.province)}` },
    { name: n.city, url: `${SITE}/${slugify(n.province)}/${slugify(n.city)}` },
    { name: n.name, url: `${SITE}/preschools/${n.slug}` },
  ]);

  const feeLabel = n.monthlyFeeMin != null
    ? n.monthlyFeeMax && n.monthlyFeeMax !== n.monthlyFeeMin
      ? `R${n.monthlyFeeMin.toLocaleString()} – R${n.monthlyFeeMax.toLocaleString()} / month`
      : `From R${n.monthlyFeeMin.toLocaleString()} / month`
    : 'Fees on request - contact the centre';

  // Related centres in the same city
  const related = await db.nursery.findMany({
    where: { city: n.city, province: n.province, slug: { not: n.slug } },
    orderBy: [{ dataCompleteness: 'desc' }],
    take: 6,
    select: { slug: true, name: true, suburb: true },
  });

  return (
    <div className="min-h-screen flex flex-col">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }} />

      {/* Header */}
      <section className="purple-blue-gradient text-white">
        <div className="container mx-auto max-w-5xl px-4 sm:px-6 py-12">
          <nav className="text-xs font-bold text-yellow-300 mb-3 flex items-center gap-1.5 flex-wrap">
            <Link href="/" className="hover:underline">Home</Link><span>/</span>
            <Link href={`/${slugify(n.province)}`} className="hover:underline">{n.province}</Link><span>/</span>
            <Link href={`/${slugify(n.province)}/${slugify(n.city)}`} className="hover:underline">{n.city}</Link>
          </nav>
          <div className="flex flex-wrap items-center gap-2 mb-3">
            {n.verificationStatus === 'Registered' && (
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/90 text-white inline-flex items-center gap-1">
                <Landmark className="w-3 h-3" /> Registered ECD
              </span>
            )}
            {n.verificationStatus === 'Owner-Claimed' && (
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-600 text-white inline-flex items-center gap-1">
                <BadgeCheck className="w-3 h-3" /> Owner Claimed
              </span>
            )}
            {n.verificationStatus === 'Verified-Pro' && (
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-400 text-amber-950 inline-flex items-center gap-1">
                <BadgeCheck className="w-3 h-3" /> Verified Pro
              </span>
            )}
            {n.emis && (
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/20 border border-white/30 inline-flex items-center gap-1">
                <FileCheck2 className="w-3 h-3" /> EMIS {n.emis}
              </span>
            )}
            {n.siteType && (
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/20 border border-white/30">{n.siteType}</span>
            )}
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold drop-shadow-md leading-tight">
            {n.name}
          </h1>
          <p className="mt-2 text-sm sm:text-base text-white/90 inline-flex items-center gap-1.5">
            <MapPin className="w-4 h-4" />
            {[n.suburb, n.city, n.province].filter(Boolean).join(', ')}
          </p>
        </div>
      </section>

      <main className="flex-grow container mx-auto max-w-5xl px-4 sm:px-6 py-10 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main column */}
        <div className="lg:col-span-2 space-y-8">
          {/* Key attributes */}
          <section className="bg-card border border-border/70 rounded-2xl p-6">
            <h2 className="font-heading text-xl font-bold mb-4">Centre information</h2>
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8">
              {[
                { icon: Calendar, label: 'Monthly fee', value: feeLabel },
                { icon: Clock, label: 'Hours', value: n.openingTime && n.closingTime ? `${n.openingTime} – ${n.closingTime}${n.operatingModel ? ` (${n.operatingModel})` : ''}` : n.operatingModel || 'Not on file' },
                { icon: Utensils, label: 'Meals', value: n.mealsProvided === true ? (n.mealsDetail || 'Meals provided') : n.mealsProvided === false ? 'Not provided' : 'Not on file' },
                { icon: HandCoins, label: 'ECD subsidy', value: n.subsidiesAccepted === true ? 'Subsidised places accepted' : n.subsidiesAccepted === false ? 'No subsidy places on record' : 'Not on file' },
                { icon: Users, label: 'Enrolment', value: n.totalChildren != null ? `~${n.totalChildren} children (survey figure)` : 'Not on file' },
                { icon: Building2, label: 'Curriculum', value: n.curriculum || 'Not specified - contact centre' },
                { icon: Landmark, label: 'Registration', value: n.registrationStatus || 'No registration info on file' },
                { icon: MapPin, label: 'Address', value: n.address || [n.suburb, n.city].filter(Boolean).join(', ') || 'Not on file' },
              ].map((row, i) => (
                <div key={i} className="flex items-start gap-3 py-2.5 border-b border-border/40 last:border-0">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <row.icon className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <dt className="text-[11px] uppercase tracking-wide text-muted-foreground font-bold">{row.label}</dt>
                    <dd className="text-sm font-semibold">{row.value}</dd>
                  </div>
                </div>
              ))}
            </dl>
            <p className="text-[11px] text-muted-foreground mt-4 leading-relaxed">
              Profile completeness: {n.dataCompleteness}/12 attributes. Data from official government
              sources ({sources.map((s) => SOURCE_LABELS[s] || s).join('; ')}). Survey figures may be
              historical - always confirm current fees and availability directly with the centre.
            </p>
          </section>

          {/* Contact + CTA */}
          <section className="bg-card border border-border/70 rounded-2xl p-6">
            <h2 className="font-heading text-xl font-bold mb-4">Contact {n.name}</h2>
            <div className="flex flex-wrap gap-3">
              {n.phone && (
                <a href={`tel:${n.phone}`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-colors">
                  <Phone className="w-4 h-4" /> {n.phone}
                </a>
              )}
              {n.email && (
                <a href={`mailto:${n.email}`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border font-bold text-sm hover:border-primary hover:text-primary transition-colors">
                  <Mail className="w-4 h-4" /> Email
                </a>
              )}
              {n.website && (
                <a href={n.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border font-bold text-sm hover:border-primary hover:text-primary transition-colors">
                  <Globe className="w-4 h-4" /> Website <ExternalLink className="w-3 h-3" />
                </a>
              )}
              {!n.phone && !n.email && (
                <p className="text-sm text-muted-foreground">
                  No direct contact details on file - search the centre by name or ask your local DSD office.
                </p>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground mt-4">
              Is this your centre? <Link href="/" className="text-primary font-bold hover:underline">Find it in the directory</Link> and use &ldquo;Claim this listing&rdquo; to verify and update details, add photos and receive parent inquiries.
            </p>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-6">
          <div className="bg-card border border-border/70 rounded-2xl p-5">
            <h3 className="font-heading text-base font-bold mb-3">Nearby options in {n.city}</h3>
            {related.length ? (
              <ul className="space-y-2.5">
                {related.map((r) => (
                  <li key={r.slug}>
                    <Link href={`/preschools/${r.slug}`} className="text-sm font-semibold hover:text-primary transition-colors block">
                      {r.name}
                      {r.suburb && <span className="text-xs text-muted-foreground font-normal block">{r.suburb}</span>}
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-muted-foreground">No other centres on file for this area yet.</p>
            )}
          </div>
          <div className="purple-blue-gradient rounded-2xl p-5 text-white">
            <h3 className="font-heading text-base font-bold mb-2">Choosing an ECD centre</h3>
            <p className="text-xs text-white/90 leading-relaxed">
              Always visit in person. Check: DSD/DBE registration certificate, staff-to-child ratios,
              safe outdoor play space, the daily routine, and whether meals meet your child&apos;s
              needs. Registered centres can access the ECD subsidy for qualifying children.
            </p>
          </div>
        </aside>
      </main>

      <footer className="bg-foreground text-background mt-auto">
        <div className="container mx-auto max-w-7xl px-4 py-6 text-xs opacity-80 text-center">
          <Link href="/" className="font-heading font-bold text-sm">Nursery<span className="text-yellow-400">Net</span></Link>
          <span className="mx-2">·</span>
          {n.name}, {n.city}, {n.province}
        </div>
      </footer>
    </div>
  );
}
