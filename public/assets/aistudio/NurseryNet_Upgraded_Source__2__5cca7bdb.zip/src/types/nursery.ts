/**
 * NurseryNet - Core Data Schema & Types
 * Path: src/types/nursery.ts
 *
 * Based on the 12 parent-centric evaluation attributes, extended to reflect
 * the real data pipeline (official DSD/DBE sources -> ETL -> directory).
 * Fields the sources don't provide stay null - never fabricated.
 */

export type AgeGroup = 'Infant (0-2 yrs)' | 'Toddler (2-4 yrs)' | 'Preschool (4-6 yrs)';

export type OperatingModel =
  | 'Half-day (till 13:00)'
  | 'Half-day (till 14:00)'
  | 'Full-day (till 17:30)'
  | 'Aftercare / Extended';

export type CurriculumType =
  | 'Play-based'
  | 'Montessori'
  | 'CAPS (South Africa)'
  | 'Waldorf'
  | 'Reggio Emilia'
  | 'Other / General';

export type VerificationStatus = 'Unverified' | 'Registered' | 'Owner-Claimed' | 'Verified-Pro';

export type Province =
  | 'Eastern Cape'
  | 'Free State'
  | 'Gauteng'
  | 'KwaZulu-Natal'
  | 'Limpopo'
  | 'Mpumalanga'
  | 'North West'
  | 'Northern Cape'
  | 'Western Cape';

export const PROVINCES: Province[] = [
  'Eastern Cape',
  'Free State',
  'Gauteng',
  'KwaZulu-Natal',
  'Limpopo',
  'Mpumalanga',
  'North West',
  'Northern Cape',
  'Western Cape',
];

export const PROVINCE_SLUGS: Record<string, string> = {
  'eastern-cape': 'Eastern Cape',
  'free-state': 'Free State',
  gauteng: 'Gauteng',
  'kwazulu-natal': 'KwaZulu-Natal',
  limpopo: 'Limpopo',
  mpumalanga: 'Mpumalanga',
  'north-west': 'North West',
  'northern-cape': 'Northern Cape',
  'western-cape': 'Western Cape',
};

/** Human-readable label for a data source key. */
export const SOURCE_LABELS: Record<string, string> = {
  'dpme-dsd1314': 'DPME/DSD National ECD Register',
  'dpme-dsd2015': 'DSD ECD Survey 2015 (DPME)',
  'dpme-dbe2017q1': 'DBE Registered ECD Centres (2017)',
  'dpme-dbe2015q1': 'DBE Registered ECD Centres (2015)',
  'dbe-underresourced-2024': 'DBE Under-Resourced ECD List (Dec 2024)',
  osm: 'OpenStreetMap contributors (ODbL)',
  'city-capetown': 'City of Cape Town Open Data',
  'wced-emis': 'WCED EMIS Directory',
};

/** A single directory listing as served by the API. */
export interface Nursery {
  id: string;
  slug: string;
  name: string;
  province: string;
  city: string;
  suburb: string | null;
  district: string | null;
  lat: number | null;
  lon: number | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  registrationStatus: string | null;
  verificationStatus: VerificationStatus;
  emis: string | null;
  mealsProvided: boolean | null;
  mealsDetail: string | null;
  monthlyFeeMin: number | null;
  monthlyFeeMax: number | null;
  openingTime: string | null;
  closingTime: string | null;
  operatingModel: OperatingModel | null;
  subsidiesAccepted: boolean | null;
  totalChildren: number | null;
  siteType: string | null;
  curriculum: CurriculumType | null;
  isFeatured: boolean;
  dataCompleteness: number;
  sources: string[];
}

/** Query params accepted by /api/nurseries. */
export interface NurseryQuery {
  q?: string;
  province?: string;
  city?: string;
  meals?: boolean;
  subsidy?: boolean;
  registered?: boolean;
  hasPhone?: boolean;
  minFee?: number;
  maxFee?: number;
  curriculum?: string;
  operatingModel?: string;
  page?: number;
  perPage?: number;
  sort?: 'relevance' | 'fee-asc' | 'fee-desc' | 'name' | 'completeness';
}

export interface NurseriesResponse {
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
  results: Nursery[];
  facets: {
    provinces: { key: string; label: string; count: number }[];
    cities: { key: string; count: number }[];
  };
}

export interface TourBookingRequest {
  nurserySlug: string;
  nurseryName: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  childAge?: string;
  preferredDate?: string;
  preferredSlot?: string;
  notes?: string;
}
