/**
 * NurseryNet - Schema.org JSON-LD Generator
 * Path: src/lib/schema-generator.ts
 *
 * Produces structured data for Google rich results / AI Overviews:
 *  - generateChildCareSchema: individual preschool profile pages
 *  - generateItemListSchema: city-level "Best preschools in X" listicles
 *  - generateBreadcrumbSchema: navigation breadcrumbs
 *
 * Only real, source-backed fields are emitted. Ratings are omitted where the
 * underlying data has none (Google penalises fake aggregateRating).
 */

export interface ChildCareSchemaInput {
  name: string;
  slug: string;
  city: string;
  province: string;
  suburb?: string | null;
  address?: string | null;
  phone?: string | null;
  email?: string | null;
  website?: string | null;
  lat?: number | null;
  lon?: number | null;
  monthlyFeeMin?: number | null;
  monthlyFeeMax?: number | null;
  openingTime?: string | null;
  closingTime?: string | null;
  registrationStatus?: string | null;
  verificationStatus?: string | null;
}

const SITE = 'https://nursery-net.vercel.app';

export function generateChildCareSchema(n: ChildCareSchemaInput) {
  const addressParts: string[] = [];
  if (n.suburb) addressParts.push(n.suburb);
  if (n.address) addressParts.push(n.address);

  const schema: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'ChildCare',
    name: n.name,
    url: `${SITE}/preschools/${n.slug}`,
    address: {
      '@type': 'PostalAddress',
      addressLocality: n.city,
      addressRegion: n.province,
      addressCountry: 'ZA',
      ...(addressParts.length ? { streetAddress: addressParts.join(', ') } : {}),
    },
    ...(n.phone ? { telephone: n.phone } : {}),
    ...(n.email ? { email: n.email } : {}),
    ...(n.website ? { sameAs: [n.website] } : {}),
    ...(n.lat && n.lon
      ? {
          geo: {
            '@type': 'GeoCoordinates',
            latitude: n.lat,
            longitude: n.lon,
          },
        }
      : {}),
    ...(n.monthlyFeeMin != null
      ? {
          priceRange: n.monthlyFeeMax
            ? `R${n.monthlyFeeMin} - R${n.monthlyFeeMax} / month`
            : `From R${n.monthlyFeeMin} / month`,
        }
      : {}),
    ...(n.openingTime && n.closingTime
      ? {
          openingHoursSpecification: {
            '@type': 'OpeningHoursSpecification',
            dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
            opens: n.openingTime,
            closes: n.closingTime,
          },
        }
      : {}),
  };

  if (n.registrationStatus && n.registrationStatus.toLowerCase().includes('fully')) {
    schema['isAccessibleForFree'] = false;
    schema['keywords'] = [
      'preschool',
      'creche',
      'day care',
      'ECD centre',
      n.city,
      n.province,
      'South Africa',
    ];
  } else {
    schema['keywords'] = [
      'preschool',
      'creche',
      'day care',
      'ECD centre',
      n.city,
      n.province,
      'South Africa',
    ];
  }

  return schema;
}

export function generateItemListSchema(
  city: string,
  province: string,
  items: { slug: string; name: string }[]
) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: `Preschools & Day Care Centres in ${city}, ${province}`,
    numberOfItems: items.length,
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      url: `${SITE}/preschools/${item.slug}`,
    })),
  };
}

export function generateBreadcrumbSchema(trail: { name: string; url: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((t, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: t.name,
      item: t.url,
    })),
  };
}
