#!/usr/bin/env python3
"""Parse the DBE 'under-resourced ECD centres' PDF (layout text) into structured records."""
import re
import json

# Column layout (from pdftotext -layout):
# Province | dc(district) | ward | gps(lat lon) | ... | school name | city/town | suburb | area | postal | Name | PhysicalAddress | ContactFirst | ContactLast
# Robust approach: regex the known repeating pattern of lat/lon then capture name/city/suburb via spacing.

txt = open('/home/z/my-project/data-raw/dbe-underresourced.txt', encoding='utf-8').read()
lines = [l.rstrip() for l in txt.split('\n') if l.strip()]

records = []
# Pattern: latitude longitude near start; capture school name as the uppercase text block
# We'll parse per line: find lines that look like data rows (contain a decimal coordinate)
latlon_re = re.compile(r'(-3[0-5]\.\d{4,})\s+([12][0-9]\.\d{4,})')

PROVINCES = {'Eastern Cape', 'Free State', 'Gauteng', 'KwaZulu Natal', 'KwaZulu-Natal', 'Limpopo',
             'Mpumalanga', 'North West', 'Northern Cape', 'Western Cape'}

current = None
for line in lines:
    m = latlon_re.search(line)
    starts_province = any(line.strip().startswith(p) for p in PROVINCES)
    if m and starts_province:
        # new record row
        if current:
            records.append(current)
        prov = None
        for p in PROVINCES:
            if line.strip().startswith(p):
                prov = p
                break
        # district = text between province and ward number
        rest = line.strip()[len(prov):].strip()
        dm = re.match(r'^(.*?)\s+(\d+)\s', rest)
        district = dm.group(1).strip() if dm else ''
        lat, lon = float(m.group(1)), float(m.group(2))
        # school name: after the second "No  " marker; fallback: last uppercase-ish column before city
        # The structure: ... No  SCHOOL NAME   CITY  SUBURB  AREA  POSTAL  NAME  PHYSICAL  FIRST  LAST
        # find "No " occurrences after coordinates
        post_coord = line[m.end():]
        no_pos = post_coord.find(' No ')
        if no_pos >= 0:
            tail = post_coord[no_pos + 4:]
        else:
            tail = post_coord
        # Split on 2+ spaces into columns
        cols = [c.strip() for c in re.split(r'\s{2,}', tail) if c.strip()]
        name = cols[0] if cols else ''
        city = cols[1] if len(cols) > 1 else ''
        suburb = cols[2] if len(cols) > 2 else ''
        current = {
            'province': prov,
            'district': district,
            'lat': lat, 'lon': lon,
            'name': name, 'city': city, 'suburb': suburb,
            'raw': tail[:200],
        }
    elif current is not None and not starts_province and not m:
        # continuation line - could be part of the row; try to extend name if line is short
        pass

if current:
    records.append(current)

# quality check
good = [r for r in records if r['name'] and len(r['name']) > 3 and r['lat'] and r['lon']]
print(f"parsed rows: {len(records)}, good: {len(good)}")
for r in good[:5]:
    print(json.dumps({k: r[k] for k in ['province', 'district', 'name', 'city', 'suburb', 'lat', 'lon']}, ensure_ascii=False))
from collections import Counter
print("\nby province:", dict(Counter(r['province'] for r in good)))
with open('/home/z/my-project/data-raw/dbe-underresourced.json', 'w') as f:
    json.dump(good, f, ensure_ascii=False)
print("saved", len(good), "-> dbe-underresourced.json")
