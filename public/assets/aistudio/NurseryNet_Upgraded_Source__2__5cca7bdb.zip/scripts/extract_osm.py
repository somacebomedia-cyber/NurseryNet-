#!/usr/bin/env python3
"""Extract all preschool-ish POIs from the SA OSM extract (kindergarten, childcare, creche, nursery tags)."""
import json
import osmium

TARGET_AMENITIES = {"kindergarten", "childcare"}
KEYWORD_VALUES = {"preschool", "creche", "crèche", "nursery school", "nursery", "playschool", "playgroup", "pre-primary", "educare"}
KEYWORD_KEYS = {"preschool"}  # e.g. preschool=yes


class POIHandler(osmium.SimpleHandler):
    def __init__(self):
        super().__init__()
        self.nodes = []
        self.ways = []
        self.seen = 0

    def is_target(self, tags):
        if not tags:
            return None
        t = dict(tags)
        amenity = t.get("amenity", "").lower()
        if amenity in TARGET_AMENITIES:
            return t
        # keyword scan on name or tags
        name = t.get("name", "").lower()
        if amenity in {"school", "training"} or amenity == "":
            if any(k in name for k in KEYWORD_VALUES) or t.get("preschool", "").lower() in {"yes", "true"}:
                # only schools that mention preschool keywords; exclude obvious non-preschools
                if "primary school" in name or "high school" in name or "secondary" in name:
                    if "preschool" in name or "creche" in name or "crèche" in name:
                        return t
                    return None
                return t
        return None


class NodeHandler(POIHandler):
    def node(self, n):
        self.seen += 1
        t = self.is_target(n.tags)
        if t:
            self.nodes.append({
                "osm_type": "node",
                "osm_id": n.id,
                "lat": n.location.lat,
                "lon": n.location.lon,
                "tags": t,
            })


class WayHandler(POIHandler):
    def __init__(self):
        super().__init__()
        self.nodes = []
        self.ways = []

    def is_target(self, tags):
        return POIHandler.is_target(self, tags)

    def node(self, n):
        pass

    def way(self, w):
        self.seen += 1
        t = self.is_target(w.tags)
        if t:
            try:
                coords = [(x.lat, x.lon) for x in w.nodes]
                if coords:
                    lats = [c[0] for c in coords]
                    lons = [c[1] for c in coords]
                    self.ways.append({
                        "osm_type": "way",
                        "osm_id": w.id,
                        "lat": sum(lats) / len(lats),
                        "lon": sum(lons) / len(lons),
                        "tags": t,
                    })
            except osmium.InvalidLocationError:
                pass


import sys

if len(sys.argv) > 1 and sys.argv[1] == "ways":
    h = WayHandler()
    h.apply_file("/home/z/my-project/data-raw/sa-latest.osm.pbf", locations=True, idx="flex_mem")
    out = h.ways
else:
    h = NodeHandler()
    h.apply_file("/home/z/my-project/data-raw/sa-latest.osm.pbf", locations=False, idx="flex_mem")
    out = h.nodes

mode = sys.argv[1] if len(sys.argv) > 1 else "nodes"
outpath = f"/home/z/my-project/data-raw/osm-sa-{mode}.json"
with open(outpath, "w") as f:
    json.dump(out, f)
print(f"{mode}: {len(out)} POIs -> {outpath}")
