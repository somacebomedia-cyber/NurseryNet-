/**
 * Seed the NurseryNet database from the ETL output.
 * Usage: bun run scripts/seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";

const db = new PrismaClient();

interface RawNursery {
  slug: string;
  name: string;
  province: string;
  city: string;
  suburb: string | null;
  district: string | null;
  lat: number | null;
  lon: number | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  registrationStatus: string | null;
  verificationStatus: string;
  mealsProvided: boolean | null;
  mealsDetail: string | null;
  monthlyFeeMin: number | null;
  monthlyFeeMax: number | null;
  openingTime: string | null;
  closingTime: string | null;
  operatingModel: string | null;
  subsidiesAccepted: boolean | null;
  totalChildren: number | null;
  siteType: string | null;
  curriculum: string | null;
  emis: string | null;
  sources: string[];
  dataCompleteness: number;
}

async function main() {
  const raw = JSON.parse(
    readFileSync("/home/z/my-project/data-processed/nurseries-unified.json", "utf-8")
  ) as RawNursery[];

  console.log(`Seeding ${raw.length} nurseries...`);

  await db.nursery.deleteMany({});

  const BATCH = 500;
  for (let i = 0; i < raw.length; i += BATCH) {
    const batch = raw.slice(i, i + BATCH).map((r) => ({
      slug: r.slug,
      name: r.name,
      province: r.province,
      city: r.city,
      suburb: r.suburb,
      district: r.district,
      lat: r.lat,
      lon: r.lon,
      address: r.address,
      phone: r.phone,
      email: r.email,
      website: r.website,
      registrationStatus: r.registrationStatus,
      verificationStatus: r.verificationStatus,
      emis: r.emis,
      mealsProvided: r.mealsProvided,
      mealsDetail: r.mealsDetail,
      monthlyFeeMin: r.monthlyFeeMin,
      monthlyFeeMax: r.monthlyFeeMax,
      openingTime: r.openingTime,
      closingTime: r.closingTime,
      operatingModel: r.operatingModel,
      subsidiesAccepted: r.subsidiesAccepted,
      totalChildren: r.totalChildren,
      siteType: r.siteType,
      curriculum: r.curriculum,
      sources: JSON.stringify(r.sources),
      dataCompleteness: r.dataCompleteness,
      // Feature the richest profiles as an initial "featured" pool (monetization slots)
      isFeatured: r.dataCompleteness >= 8,
    }));
    await db.nursery.createMany({ data: batch });
    if ((i / BATCH) % 10 === 0) console.log(`  ${i + batch.length}/${raw.length}`);
  }

  const total = await db.nursery.count();
  console.log(`Seeded ${total} nurseries.`);

  const byProv = await db.nursery.groupBy({ by: ["province"], _count: { _all: true } });
  console.log(byProv.map((p) => `${p.province}: ${p._count._all}`).join("\n"));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
