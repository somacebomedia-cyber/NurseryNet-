#!/usr/bin/env python3
"""Download DPME ECD/MapServer/0 (DBE2017Q1) using FID-range paging (no pagination support)."""
import json
import time
import urllib.request
import urllib.parse
import os

SVC = "https://dpmegis.dpme.gov.za/arcgis/rest/services/ECD/MapServer/0"
OUT = "/home/z/my-project/data-raw"
STEP = 900


def post(url, params):
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            print(f"    attempt {attempt+1} failed: {e}")
            time.sleep(4 * (attempt + 1))
    return {}


out_path = os.path.join(OUT, "dpme-dbe2017q1.json")
existing = []
if os.path.exists(out_path):
    d = json.load(open(out_path))
    if d.get("done") and d.get("features"):
        print("already complete")
        raise SystemExit

# get max FID
meta = post(f"{SVC}/query", {"where": "1=1", "returnCountOnly": "true", "f": "json"})
total = meta.get("count", 0)
print("count:", total)

features = []
last_fid = -1
while True:
    where = f"FID > {last_fid}"
    d = post(f"{SVC}/query", {
        "where": where,
        "outFields": "*",
        "returnGeometry": "true",
        "outSR": "4326",
        "orderByFields": "FID",
        "f": "json",
    })
    batch = d.get("features", [])
    if not batch:
        break
    features.extend(batch)
    fids = [f["attributes"].get("FID") for f in batch if f["attributes"].get("FID") is not None]
    if not fids:
        break
    last_fid = max(fids)
    print(f"  {len(features)} fetched, lastFID={last_fid}")
    with open(out_path, "w") as f:
        json.dump({"total": total, "features": features, "done": False}, f)
    time.sleep(0.2)
    if len(batch) < STEP:
        break

with open(out_path, "w") as f:
    json.dump({"total": total, "features": features, "done": True}, f)
print(f"DONE: {len(features)} features")
