#!/usr/bin/env python3
"""
Download all ECD centre layers from the DPME ArcGIS server (paginated).
Sources:
  - SocialServices/MapServer/4 : ECD (DSD1314) national register  (~18,199)
  - ECD/MapServer/0            : ECD (DBE2017Q1)                  (~3,828)
  - ECD/MapServer/1            : ECD (DBE2015Q1)                  (~4,195)
  - ECD/MapServer/3            : ECD (DSD2015)                    (~19,577)
"""
import json
import time
import urllib.request
import urllib.parse
import os

BASE = "https://dpmegis.dpme.gov.za/arcgis/rest/services"
OUT = "/home/z/my-project/data-raw"
os.makedirs(OUT, exist_ok=True)

LAYERS = {
    "dpme-dsd1314": f"{BASE}/SocialServices/MapServer/4",
    "dpme-dbe2017q1": f"{BASE}/ECD/MapServer/0",
    "dpme-dbe2015q1": f"{BASE}/ECD/MapServer/1",
    "dpme-dsd2015": f"{BASE}/ECD/MapServer/3",
}

PAGE = 2000
RESUME = True


def post(url, params):
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0", "Content-Type": "application/x-www-form-urlencoded"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            print(f"    attempt {attempt+1} failed: {e}; retrying...")
            time.sleep(5 * (attempt + 1))
    raise RuntimeError("failed after retries")


def save_partial(name, features, total, done=False):
    path = os.path.join(OUT, f"{name}.json")
    with open(path, "w") as f:
        json.dump({"total": total, "features": features, "done": done}, f)


def load_partial(name):
    path = os.path.join(OUT, f"{name}.json")
    if RESUME and os.path.exists(path):
        try:
            d = json.load(open(path))
            if not d.get("done"):
                return d.get("features", []), d.get("total", 0)
            # already complete
            return None, None
        except Exception:
            pass
    return [], 0


for name, svc in LAYERS.items():
    features, total = load_partial(name)
    if features is None:
        print(f"{name}: complete, skip")
        continue
    if total == 0:
        meta = post(f"{svc}/query", {"where": "1=1", "returnCountOnly": "true", "f": "json"})
        total = meta.get("count", 0)
    print(f"Downloading {name} ... count={total}, resume_from={len(features)}")
    offset = len(features)
    if features:
        # rebuild offset: features may include a few pages
        offset = (len(features) // PAGE) * PAGE
        features = features[:offset]
    last_save = time.time()
    while offset < total:
        d = post(f"{svc}/query", {
            "where": "1=1",
            "outFields": "*",
            "returnGeometry": "true",
            "outSR": "4326",
            "resultOffset": str(offset),
            "resultRecordCount": str(PAGE),
            "f": "json",
        })
        batch = d.get("features", [])
        if not batch:
            break
        features.extend(batch)
        offset += len(batch)
        if time.time() - last_save > 15:
            save_partial(name, features, total)
            last_save = time.time()
            print(f"  {offset}/{total} (saved)")
        time.sleep(0.15)
    save_partial(name, features, total, done=True)
    print(f"  DONE {len(features)} features -> {name}.json")
print("ALL DONE")
