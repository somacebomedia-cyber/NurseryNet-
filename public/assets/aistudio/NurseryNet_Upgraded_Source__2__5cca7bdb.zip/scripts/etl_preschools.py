#!/usr/bin/env python3
"""
NurseryNet ETL Master Pipeline
==============================
Normalizes 8 real South African ECD data sources into a unified, deduplicated
preschool directory, then exports JSON for the app database + CSV for review.

Sources (all real, government / open data):
  1. dpme-dsd1314.json      DPME/DSD national ECD register 2013/14 (18,199)
  2. dpme-dsd2015.json      DPME/DSD ECD survey 2015 (19,577) - rich operational data
  3. dpme-dbe2017q1.json    DBE registered ECD centres 2017 Q1 (3,828)
  4. dpme-dbe2015q1.json    DBE registered ECD centres 2015 Q1 (4,195)
  5. dbe-underresourced.json DBE list of under-resourced ECD centres Dec 2024 (2,548)
  6. osm-sa-nodes/ways.json OpenStreetMap SA preschool POIs (981, ODbL)
  7. cct-ecd.csv            City of Cape Town owned ECD centres (37)
  8. wced-emis-ecd.json     WCED EMIS ECD directory (330)
"""
import json
import csv
import math
import re
import unicodedata
from collections import defaultdict

RAW = "/home/z/my-project/data-raw"
OUT_JSON = "/home/z/my-project/data-processed/nurseries-unified.json"
OUT_CSV = "/home/z/my-project/data-processed/nurseries-unified.csv"
OUT_STATS = "/home/z/my-project/data-processed/etl-stats.json"

import os
os.makedirs("/home/z/my-project/data-processed", exist_ok=True)

PROVINCE_MAP = {
    "EC": "Eastern Cape", "FS": "Free State", "GT": "Gauteng", "GP": "Gauteng",
    "KZN": "KwaZulu-Natal", "NL": "KwaZulu-Natal", "LP": "Limpopo", "MP": "Mpumalanga",
    "NW": "North West", "NC": "Northern Cape", "WC": "Western Cape",
    "EASTERN CAPE": "Eastern Cape", "FREE STATE": "Free State", "GAUTENG": "Gauteng",
    "KWAZULU-NATAL": "KwaZulu-Natal", "KWAZULU NATAL": "KwaZulu-Natal", "LIMPOPO": "Limpopo",
    "MPUMALANGA": "Mpumalanga", "NORTH WEST": "North West", "NORTHERN CAPE": "Northern Cape",
    "WESTERN CAPE": "Western Cape",
}

INVALID_PLACES = {"unknown", "unkown", "to be updated", "n/a", "na", "none", "null", "", "tbc",
                  "0", "not applicable", "no", "yes", "false", "true", "-", "nan"}

# South Africa bounds (rough, incl. Prince Edward is excluded)
SA_LAT = (-35.6, -21.8)
SA_LON = (15.9, 33.2)


def norm_province(p):
    if not p:
        return None
    return PROVINCE_MAP.get(str(p).strip().upper(), PROVINCE_MAP.get(str(p).strip(), None))


def clean_str(v):
    if v is None:
        return None
    s = str(v).strip()
    if s in ("", "nan", "None", "NaN", "0", "-", "N/A", "na", "null", "No", "Yes"):
        # keep No/Yes OUT of strings; numbers like 0 meaningless for strings
        if s in ("", "nan", "None", "NaN", "-", "N/A", "na", "null"):
            return None
    return s


def clean_phone(v):
    if not v:
        return None
    s = re.sub(r"[^\d+]", "", str(v))
    if len(s) < 9:
        return None
    if s.startswith("27"):
        return "+" + s
    if s.startswith("0"):
        return "+27" + s[1:]
    return "+" + s if s.startswith("+") else s


def valid_coords(lat, lon):
    try:
        la, lo = float(lat), float(lon)
    except (TypeError, ValueError):
        return None
    if math.isnan(la) or math.isnan(lo):
        return None
    if not (SA_LAT[0] <= la <= SA_LAT[1] and SA_LON[0] <= lo <= SA_LON[1]):
        return None
    return (la, lo)


def parse_fee(v):
    """'R 150.00' / '150' / 150 -> int ZAR/month or None"""
    if v is None:
        return None
    s = str(v).strip()
    if not s or s.lower() in ("nan", "none"):
        return None
    m = re.search(r"(\d+(?:\.\d+)?)", s)
    if not m:
        return None
    val = float(m.group(1))
    # Floor R10: below that (R1-R9) is survey entry noise; R10-R40 was a real
    # fee level for low-income community ECDs in the 2015 DSD survey.
    if val < 10 or val > 20000:
        return None
    return int(round(val))


def norm_name(s):
    """Normalized name key for dedup."""
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", s)
    s = s.lower()
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    # unify common abbreviations
    s = s.replace("daycare", "day care").replace("creche", "day care").replace("crèche", "day care")
    s = s.replace("educare", "educare").replace("pre school", "preschool").replace("preprimary", "pre primary")
    return s


def haversine(a, b):
    """meters between (lat,lon) tuples"""
    if not a or not b:
        return 1e12
    lat1, lon1, lat2, lon2 = map(math.radians, [a[0], a[1], b[0], b[1]])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * 6371000 * math.asin(math.sqrt(h))


def slugify(text):
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = re.sub(r"[^\w\s-]", "", text.lower())
    text = re.sub(r"[\s_-]+", "-", text).strip("-")
    return text


records = []  # unified intermediates


def add(source, name, province, city, suburb, lat, lon, phone=None, email=None,
        website=None, address=None, registration=None, meals=None, meals_detail=None,
        fee_min=None, fee_max=None, opening=None, closing=None, subsidy=None,
        total_children=None, site_type=None, emis=None, district=None, source_id=None,
        extra_name=None, osm_tags=None):
    if not name or len(str(name).strip()) < 3:
        return
    prov = norm_province(province)
    coords = valid_coords(lat, lon)
    records.append({
        "source": source,
        "sourceId": source_id,
        "name": str(name).strip(),
        "province": prov,
        "city": clean_str(city),
        "suburb": clean_str(suburb),
        "district": clean_str(district),
        "lat": coords[0] if coords else None,
        "lon": coords[1] if coords else None,
        "phone": clean_phone(phone),
        "email": clean_str(email).lower() if clean_str(email) and "@" in str(email) else None,
        "website": clean_str(website) if clean_str(website) and "." in str(clean_str(website) or "") else None,
        "address": clean_str(address),
        "registration": clean_str(registration),
        "mealsProvided": meals,
        "mealsDetail": clean_str(meals_detail),
        "feeMin": fee_min,
        "feeMax": fee_max,
        "openingTime": clean_str(opening),
        "closingTime": clean_str(closing),
        "subsidyAccepted": subsidy,
        "totalChildren": total_children if isinstance(total_children, int) and total_children > 0 else None,
        "siteType": clean_str(site_type),
        "emis": clean_str(emis),
        "osmTags": osm_tags,
    })


# ---------------------------------------------------------------- 1. DSD1314
d = json.load(open(f"{RAW}/dpme-dsd1314.json"))
for f in d["features"]:
    a = f["attributes"]
    g = f.get("geometry") or {}
    lat, lon = a.get("LAT"), a.get("LON")
    if lat in (None, 0) or lon in (None, 0):
        lat, lon = g.get("y"), g.get("x")
    phone = a.get("TEL_CELL") or a.get("TEL_LAND")
    add("dpme-dsd1314", a.get("ECDNAME"), a.get("PROVINCE"), a.get("TOWN"), a.get("SUBURB"),
        lat, lon, phone=phone, email=a.get("EMAIL"), website=a.get("WEBSITE"),
        address=" ".join(str(x) for x in [a.get("PLOT_NUM"), a.get("STR_NAME")] if x and str(x).strip() not in ("", "0")) or None,
        registration=a.get("DSD_REG"), district=a.get("LOC_MUN"),
        site_type=a.get("AREA_TYP"), source_id=a.get("ID"))

# ---------------------------------------------------------------- 2. DSD2015
d = json.load(open(f"{RAW}/dpme-dsd2015.json"))
for f in d["features"]:
    a = f["attributes"]
    g = f.get("geometry") or {}
    lat, lon = a.get("latitude"), a.get("longitude")
    gx, gy = g.get("x"), g.get("y")
    if (lat in (None, 0) or lon in (None, 0)) and gx is not None:
        # geometry may be "NaN" strings
        try:
            lont, latt = float(gx), float(gy)
            if not math.isnan(latt) and not math.isnan(lont):
                lat, lon = latt, lont
        except (TypeError, ValueError):
            pass
    # fees: fees_aged_ (0-1yr), fees_aged1 (1-2), fees_age_1 (2-3), fees_age_2..3 (3-5)
    fees = [parse_fee(a.get(k)) for k in ("fees_aged_", "fees_aged1", "fees_age_1", "fees_age_2", "fees_age_3")]
    fees = [x for x in fees if x]
    tc = a.get("total_chil")
    try:
        tc = int(float(tc)) if tc not in (None, "", " ") else None
    except (TypeError, ValueError):
        tc = None
    add("dpme-dsd2015", a.get("name_of_si"), a.get("Province"), a.get("address_to"),
        a.get("address_su"), lat, lon,
        phone=a.get("tel_cell") or a.get("tel_landli"), email=a.get("email"), website=a.get("website"),
        registration=("Yes" if str(a.get("registered", "")).strip() == "Yes" else
                      ("No" if str(a.get("registered", "")).strip() == "No" else None)),
        meals=(True if str(a.get("any_meals_", "")).strip() == "Yes" else
               (False if str(a.get("any_meals_", "")).strip() == "No" else None)),
        meals_detail=a.get("meals_prov"),
        fee_min=min(fees) if fees else None, fee_max=max(fees) if fees else None,
        opening=a.get("hours_of_o"), closing=a.get("hours_of_1"),
        subsidy=(True if str(a.get("receives_d", "")).strip() == "Yes" else
                 (False if str(a.get("receives_d", "")).strip() == "No" else None)),
        total_children=tc, site_type=a.get("type_of_si"), district=a.get("local_muni"),
        source_id=str(a.get("OBJECTID")))

def strip_muni(name):
    """'POLOKWANE LOCAL MUNICIPALITY' -> 'Polokwane'"""
    if not name:
        return None
    s = str(name).strip()
    s = re.sub(r"\s+(LOCAL|DISTRICT)\s+MUNICIPALITY$", "", s, flags=re.I)
    s = re.sub(r"\s+MUNICIPALITY$", "", s, flags=re.I)
    return s if s else None


def first_valid(*vals):
    for v in vals:
        if v is not None and str(v).strip() and str(v).strip().lower() not in INVALID_PLACES:
            return strip_muni(v)
    return None


# ---------------------------------------------------------------- 3. DBE2017Q1
d = json.load(open(f"{RAW}/dpme-dbe2017q1.json"))
for f in d["features"]:
    a = f["attributes"]
    add("dpme-dbe2017q1", a.get("Institutio"), a.get("Province"), first_valid(a.get("Town_City"), a.get("LMunName"), a.get("DMunName"), a.get("EIDistrict")),
        first_valid(a.get("Suburb"), a.get("Township_V")), a.get("GIS_Lat"), a.get("GIS_Long"),
        phone=a.get("cellno") or a.get("Telephone"), address=a.get("StreetAddr"),
        emis=a.get("NatEmis"), district=first_valid(a.get("LMunName"), a.get("DMunName"), a.get("EIDistrict")),
        source_id=str(a.get("FID")))

# ---------------------------------------------------------------- 4. DBE2015Q1
d = json.load(open(f"{RAW}/dpme-dbe2015q1.json"))
for f in d["features"]:
    a = f["attributes"]
    add("dpme-dbe2015q1", a.get("Institutio"), a.get("Province"), first_valid(a.get("Town_City"), a.get("LMunName"), a.get("DMunName"), a.get("EIDistrict")),
        first_valid(a.get("Suburb"), a.get("Township_V")), a.get("GIS_Lat"), a.get("GIS_Long"),
        phone=a.get("cellno") or a.get("Telephone"), address=a.get("StreetAddr"),
        emis=a.get("NatEmis"), district=first_valid(a.get("LMunName"), a.get("DMunName"), a.get("EIDistrict")), source_id=str(a.get("OBJECTID")))

# ---------------------------------------------------------------- 5. Under-resourced 2024
d = json.load(open(f"{RAW}/dbe-underresourced.json"))
for r in d:
    add("dbe-underresourced-2024", r["name"], r["province"], r["city"], r["suburb"],
        r["lat"], r["lon"], district=r["district"])

# ---------------------------------------------------------------- 6. OSM
osm = []
for fn in ("osm-sa-nodes.json", "osm-sa-ways.json"):
    osm.extend(json.load(open(f"{RAW}/{fn}")))
for o in osm:
    t = o["tags"]
    if not t.get("name"):
        continue
    add("osm", t["name"], "Gauteng", t.get("addr:city"), t.get("addr:suburb"),
        o["lat"], o["lon"], phone=t.get("phone") or t.get("contact:phone"),
        email=t.get("email") or t.get("contact:email"), website=t.get("website") or t.get("contact:website"),
        address=" ".join(str(x) for x in [t.get("addr:housenumber"), t.get("addr:street")] if x) or None,
        source_id=f'{o["osm_type"]}/{o["osm_id"]}', osm_tags={k: v for k, v in t.items() if k in ("operator", "opening_hours", "capacity")})

# ---------------------------------------------------------------- 7. City of Cape Town
with open(f"{RAW}/cct-ecd.csv", encoding="utf-8-sig") as fh:
    for row in csv.DictReader(fh):
        add("city-capetown", row.get("ECD_NAME"), "Western Cape", "Cape Town", row.get("SBRB"),
            None, None, address=row.get("ADRS"))

# ---------------------------------------------------------------- 8. WCED EMIS
d = json.load(open(f"{RAW}/wced-emis-ecd.json"))
for r in d:
    add("wced-emis", r["name"], "Western Cape", None, None, None, None,
        emis=r["emis"], district=r["district"])

print(f"Raw normalized records: {len(records)}")

# ---- sanitize junk location strings across all sources ----
cleaned = 0
for r in records:
    for fld in ("city", "suburb", "district"):
        v = (r.get(fld) or "").strip().lower()
        if v in INVALID_PLACES:
            if r[fld]:
                r[fld] = None
                cleaned += 1
print(f"Sanitized {cleaned} junk place values")

# ================================================================ DEDUP & MERGE
# Priority: under-resourced-2024 (freshest GPS) > dsd1314 > dsd2015 > dbe2017 > dbe2015 > osm > others
PRIORITY = {
    "dbe-underresourced-2024": 8, "dpme-dsd1314": 7, "dpme-dsd2015": 6,
    "dpme-dbe2017q1": 5, "dpme-dbe2015q1": 4, "osm": 3, "city-capetown": 2, "wced-emis": 2,
}

# group by province+namekey first
groups = defaultdict(list)
for r in records:
    r["_namekey"] = norm_name(r["name"])
    r["_prio"] = PRIORITY.get(r["source"], 1)
    groups[(r["province"], r["_namekey"])].append(r)

# fields to merge
MERGE_FIELDS = ["city", "suburb", "district", "lat", "lon", "phone", "email", "website", "address",
                "registration", "mealsProvided", "mealsDetail", "feeMin", "feeMax", "openingTime",
                "closingTime", "subsidyAccepted", "totalChildren", "siteType", "emis", "sourceId"]


def dist(r):
    return (r["lat"], r["lon"]) if r["lat"] else None


merged = []
dup_stats = defaultdict(int)
for key, grp in groups.items():
    grp.sort(key=lambda r: -r["_prio"])
    clusters = []
    for r in grp:
        placed = False
        for c in clusters:
            # same cluster if within 750m or same city+suburb text
            if r["lat"] and c[0]["lat"] and haversine(dist(r), dist(c[0])) < 750:
                c.append(r); placed = True; break
            if (r["city"] and c[0]["city"] and r["city"].lower() == c[0]["city"].lower()
                    and (not r["lat"] or not c[0]["lat"])):
                c.append(r); placed = True; break
        if not placed:
            clusters.append([r])
    for c in clusters:
        if len(c) > 1:
            dup_stats[len(c)] += 1
        base = dict(c[0])
        base["_sources"] = [c[0]["source"]]
        for other in c[1:]:
            base["_sources"].append(other["source"])
            for fld in MERGE_FIELDS:
                if base.get(fld) in (None, "", False) and other.get(fld) not in (None, ""):
                    # booleans: only copy if base is None (not False)
                    if isinstance(other.get(fld), bool) and base.get(fld) is False:
                        continue
                    base[fld] = other[fld]
        merged.append(base)

print(f"After name-key dedup: {len(merged)}")

# cross-check: WCED EMIS records have no coords; they match DSD1314 WC entries by name+city already
# (province+namekey grouping handles it since both normalized)

# fallback city: use suburb, district, or gazetteer nearest-city via GPS
INVALID_CITIES = {"unknown", "unkown", "to be updated", "n/a", "na", "none", "null", "", "tbc", "0"}
CITY_ALIASES = {
    "city of cape town": "Cape Town",
    "city of tshwane": "Pretoria",
    "city of johannesburg": "Johannesburg",
    "city of ekurhuleni": "Ekurhuleni (East Rand)",
    "ekurhuleni": "Ekurhuleni (East Rand)",
    "ekurhuleni metropolitan": "Ekurhuleni (East Rand)",
    "city of tshwane metropolitan": "Pretoria",
    "city of johannesburg metropolitan": "Johannesburg",
    "mangaung": "Bloemfontein",
    "nelson mandela bay": "Port Elizabeth",
    "nelson mandela": "Port Elizabeth",
    "buffalo city": "East London",
    "kwadukuza": "KwaDukuza",
    "raymond mhlaba": "Raymond Mhlaba",
}


def alias_city(c):
    if not c:
        return None
    key = re.sub(r"\s+", " ", str(c).strip().lower())
    if key in CITY_ALIASES:
        return CITY_ALIASES[key]
    # generic: strip metropolitan/metropolis suffix
    key2 = re.sub(r"\s+metropolitan( municipality)?$", "", key)
    if key2 in CITY_ALIASES:
        return CITY_ALIASES[key2]
    return c

# ---- Build gazetteer from records that have (city, coords) ----
gazetteer = defaultdict(list)  # province -> [(name, lat, lon)]
for r in merged:
    c = (r["city"] or "").strip().lower()
    if c and c not in INVALID_CITIES and r["lat"]:
        cname = CITY_ALIASES.get(c, r["city"].strip())
        gazetteer[r["province"]].append((cname, r["lat"], r["lon"]))

# precompute
gaz_list = {p: [(n, la, lo) for n, la, lo in v] for p, v in gazetteer.items()}
print(f"Gazetteer cities: {sum(len(v) for v in gaz_list.values())} points across {len(gaz_list)} provinces")


def nearest_city(prov, lat, lon, max_km=25):
    cands = gaz_list.get(prov)
    if not cands or lat is None:
        return None, None
    best, bd = None, 1e13
    for n, la, lo in cands:
        d = haversine((lat, lon), (la, lo))
        if d < bd:
            best, bd = n, d
    if best is not None and bd <= max_km * 1000:
        # distance bucket for confidence
        return best, ("exact" if bd < 3000 else "near")
    return None, None


city_fixes = defaultdict(int)
for r in merged:
    c = (r["city"] or "").strip().lower()
    if c in INVALID_CITIES:
        r["city"] = None
    else:
        r["city"] = alias_city(r["city"].strip()) if r["city"] else None
    if r["district"]:
        r["district"] = alias_city(r["district"].strip())
    if not r["city"]:
        # try gazetteer by GPS
        if r["lat"]:
            city, conf = nearest_city(r["province"], r["lat"], r["lon"])
            if city:
                r["city"] = city
                city_fixes[f"gazetteer-{conf}"] += 1
                continue
        # fallback chain: suburb -> district
        sub = (r.get("suburb") or "").strip()
        dis = (r.get("district") or "").strip()
        if sub and sub.lower() not in INVALID_CITIES and len(sub) > 2:
            r["city"] = CITY_ALIASES.get(sub.lower(), sub)
            city_fixes["suburb"] += 1
        elif dis and dis.lower() not in INVALID_CITIES:
            r["city"] = CITY_ALIASES.get(dis.lower(), dis)
            city_fixes["district"] += 1
        else:
            r["city"] = None
            city_fixes["none"] += 1

print("City resolution:", dict(city_fixes))

# drop records with no province (can't place them in a directory)
before = len(merged)
merged = [r for r in merged if r["province"]]
print(f"Dropped {before - len(merged)} records without province -> {len(merged)}")

# ================================================================ FINAL MODEL
PROV_ORDER = ["Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo",
              "Mpumalanga", "North West", "Northern Cape", "Western Cape"]

CURRICULUM_HINTS = [
    ("montessori", "Montessori"),
    ("waldorf", "Waldorf"),
    ("reggio", "Reggio Emilia"),
    ("steiner", "Waldorf"),
    ("playgroup", "Play-based"),
    ("play group", "Play-based"),
]

def smart_title(s):
    """Title-case an ALL-CAPS string, preserving mixed-case and small words."""
    if not s:
        return s
    if s.isupper() or (s.islower() and len(s) > 3):
        return s.title()
    return s


out = []
slug_seen = defaultdict(int)
for r in merged:
    name = r["name"]
    name = " ".join(w[0].upper() + w[1:] if w.isupper() and len(w) > 3 else w for w in name.split()) if name.isupper() else name
    name = re.sub(r"\s+", " ", name).strip()
    city = smart_title((r["city"] or "").strip()) or None
    suburb = smart_title((r["suburb"] or "").strip()) or None
    district = smart_title((r["district"] or "").strip()) or None
    if not city:
        city = f"{r['province']} (unassigned area)"

    # curriculum from name
    curriculum = None
    nl = name.lower()
    for hint, label in CURRICULUM_HINTS:
        if hint in nl:
            curriculum = label
            break

    # registration -> verification status
    reg = (r.get("registration") or "").lower()
    if "full" in reg or reg == "yes":
        verification = "Registered"
        reg_label = "Fully registered (DSD/DBE)"
    elif "partial" in reg or "conditional" in reg or "provisional" in reg:
        verification = "Registered"
        reg_label = "Provisionally registered"
    elif "not" in reg or reg == "no":
        verification = "Unverified"
        reg_label = "Not registered at time of survey"
    else:
        verification = "Unverified"
        reg_label = None

    # operating model from hours
    op_model = None
    if r.get("closingTime"):
        try:
            ch = int(str(r["closingTime"]).split(":")[0])
            if ch >= 17:
                op_model = "Full-day (till 17:30)"
            elif ch >= 14:
                op_model = "Half-day (till 14:00)"
            else:
                op_model = "Half-day (till 13:00)"
        except (ValueError, IndexError):
            pass

    slug_base = slugify(f'{name}-{city}')
    slug_seen[slug_base] += 1
    slug = slug_base if slug_seen[slug_base] == 1 else f'{slug_base}-{slug_seen[slug_base]}'

    # completeness score (out of 12 attribute groups)
    checks = [r.get("lat"), r.get("phone"), r.get("mealsProvided") is not None,
              r.get("feeMin"), r.get("openingTime"), r.get("subsidyAccepted") is not None,
              r.get("totalChildren"), r.get("siteType"), r.get("email"), r.get("website"),
              curriculum, op_model]
    completeness = sum(1 for c in checks if c)

    out.append({
        "slug": slug,
        "name": name,
        "province": r["province"],
        "city": city,
        "suburb": suburb,
        "district": district,
        "lat": r["lat"], "lon": r["lon"],
        "phone": r["phone"], "email": r["email"], "website": r["website"],
        "address": r["address"],
        "registrationStatus": reg_label,
        "verificationStatus": verification,
        "mealsProvided": r["mealsProvided"],
        "mealsDetail": r["mealsDetail"],
        "monthlyFeeMin": r["feeMin"], "monthlyFeeMax": r["feeMax"],
        "openingTime": r["openingTime"], "closingTime": r["closingTime"],
        "operatingModel": op_model,
        "subsidiesAccepted": r["subsidyAccepted"],
        "totalChildren": r["totalChildren"],
        "siteType": r["siteType"],
        "curriculum": curriculum,
        "emis": r["emis"],
        "sources": sorted(set(r["_sources"])),
        "dataCompleteness": completeness,
    })

# sort: province, city, name
out.sort(key=lambda x: (PROV_ORDER.index(x["province"]), x["city"], x["name"]))

json.dump(out, open(OUT_JSON, "w"), ensure_ascii=False)
print(f"FINAL unified records: {len(out)}")

# stats
from collections import Counter
prov_counts = Counter(x["province"] for x in out)
city_counts = Counter(f'{x["city"]}, {x["province"]}' for x in out)
with_geo = sum(1 for x in out if x["lat"])
with_phone = sum(1 for x in out if x["phone"])
with_fees = sum(1 for x in out if x["monthlyFeeMin"])
with_meals = sum(1 for x in out if x["mealsProvided"] is not None)
with_reg = sum(1 for x in out if x["registrationStatus"])
with_emis = sum(1 for x in out if x["emis"])
stats = {
    "total": len(out),
    "by_province": dict(prov_counts),
    "top_cities": city_counts.most_common(40),
    "with_gps": with_geo, "with_phone": with_phone, "with_fees": with_fees,
    "with_meals_info": with_meals, "with_registration_info": with_reg, "with_emis": with_emis,
    "source_contribution": dict(Counter(s for x in out for s in x["sources"])),
    "raw_records": len(records),
    "cluster_sizes": {str(k): v for k, v in sorted(dup_stats.items())},
}
json.dump(stats, open(OUT_STATS, "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in stats.items() if k != "top_cities"}, indent=1, ensure_ascii=False))
print("\nTop 15 cities:", city_counts.most_common(15))

# CSV export
with open(OUT_CSV, "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
    w.writeheader()
    w.writerows(out)
print(f"CSV -> {OUT_CSV}")
