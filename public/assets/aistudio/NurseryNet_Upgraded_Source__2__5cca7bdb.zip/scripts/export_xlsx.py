#!/usr/bin/env python3
"""
NurseryNet - Database Export to XLSX
Creates download/NurseryNet_SA_ECD_Directory.xlsx with:
  - Summary sheet (stats by province, coverage, sources)
  - City Coverage sheet
  - All Centres sheet (30,424 rows, write-only for performance)
"""
import json
import sys
import os
from collections import Counter

XLSX_SKILL_DIR = "/home/z/my-project/skills/xlsx"
for sub in [XLSX_SKILL_DIR, os.path.join(XLSX_SKILL_DIR, "templates")]:
    if sub not in sys.path:
        sys.path.insert(0, sub)

import base  # skill design system
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

base.use_palette_explicit("professional")

PRIMARY = base.PRIMARY
SECONDARY = base.SECONDARY
NEUTRAL_100 = base.NEUTRAL_100
NEUTRAL_600 = base.NEUTRAL_600
NEUTRAL_900 = base.NEUTRAL_900

DATA = json.load(open("/home/z/my-project/data-processed/nurseries-unified.json"))
STATS = json.load(open("/home/z/my-project/data-processed/etl-stats.json"))

SOURCE_LABELS = {
    "dpme-dsd1314": "DPME/DSD National ECD Register (2013/14)",
    "dpme-dsd2015": "DSD ECD Survey 2015 (via DPME)",
    "dpme-dbe2017q1": "DBE Registered ECD Centres (2017 Q1)",
    "dpme-dbe2015q1": "DBE Registered ECD Centres (2015 Q1)",
    "dbe-underresourced-2024": "DBE Under-Resourced ECD List (Dec 2024)",
    "osm": "OpenStreetMap (ODbL)",
    "city-capetown": "City of Cape Town Open Data",
    "wced-emis": "WCED EMIS Directory",
}

OUT = "/home/z/my-project/download/NurseryNet_SA_ECD_Directory.xlsx"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

wb = Workbook()

# ============================================================ Sheet 1: Summary
ws = wb.active
ws.title = "Summary"
ws.sheet_view.showGridLines = False

ws["B2"] = "NurseryNet - South Africa ECD Directory Data Export"
ws["B2"].font = Font(name=base.FONT_NAME, size=16, bold=True, color=PRIMARY)
ws["B3"] = f"{len(DATA):,} unique ECD centres from official government open-data sources - exported 2026-11-08"
ws["B3"].font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_600)

r = 5
ws.cell(row=r, column=2, value="Centres by Province").font = Font(name=base.FONT_NAME, size=12, bold=True, color=PRIMARY)
r += 1
headers = ["Province", "Centres", "With GPS", "With Phone", "With Fees", "Registered Info"]
for c, h in enumerate(headers, 2):
    cell = ws.cell(row=r, column=c, value=h)
    cell.font = Font(name=base.FONT_NAME, size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=PRIMARY)
    cell.alignment = Alignment(horizontal="left")
hdr_row = r

prov_order = ["Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo",
              "Mpumalanga", "North West", "Northern Cape", "Western Cape"]
by_prov = {}
for x in DATA:
    p = by_prov.setdefault(x["province"], {"n": 0, "gps": 0, "ph": 0, "fee": 0, "reg": 0})
    p["n"] += 1
    p["gps"] += 1 if x["lat"] else 0
    p["ph"] += 1 if x["phone"] else 0
    p["fee"] += 1 if x["monthlyFeeMin"] else 0
    p["reg"] += 1 if x["registrationStatus"] else 0

r += 1
first_data = r
for prov in prov_order:
    p = by_prov.get(prov, {"n": 0, "gps": 0, "ph": 0, "fee": 0, "reg": 0})
    vals = [prov, p["n"], p["gps"], p["ph"], p["fee"], p["reg"]]
    for c, v in enumerate(vals, 2):
        cell = ws.cell(row=r, column=c, value=v)
        cell.font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
        if isinstance(v, int):
            cell.number_format = "#,##0"
    if (r - first_data) % 2 == 1:
        for c in range(2, 8):
            ws.cell(row=r, column=c).fill = PatternFill("solid", fgColor=NEUTRAL_100)
    r += 1
# totals
tot = ["TOTAL", len(DATA), sum(1 for x in DATA if x["lat"]), sum(1 for x in DATA if x["phone"]),
       sum(1 for x in DATA if x["monthlyFeeMin"]), sum(1 for x in DATA if x["registrationStatus"])]
for c, v in enumerate(tot, 2):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = Font(name=base.FONT_NAME, size=10, bold=True, color=PRIMARY)
    cell.fill = PatternFill("solid", fgColor=SECONDARY)
    if isinstance(v, int):
        cell.number_format = "#,##0"

r += 3
ws.cell(row=r, column=2, value="Data Sources").font = Font(name=base.FONT_NAME, size=12, bold=True, color=PRIMARY)
r += 1
for c, h in enumerate(["Source", "Contributing records*"], 2):
    cell = ws.cell(row=r, column=c, value=h)
    cell.font = Font(name=base.FONT_NAME, size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=PRIMARY)
r += 1
for key, cnt in STATS["source_contribution"].items():
    ws.cell(row=r, column=2, value=SOURCE_LABELS.get(key, key)).font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
    cell = ws.cell(row=r, column=3, value=cnt)
    cell.font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
    cell.number_format = "#,##0"
    r += 1
r += 1
ws.cell(row=r, column=2, value="* A centre can appear in multiple sources; listings merge the richest fields from each (raw records: {:,}).".format(STATS["raw_records"])).font = Font(name=base.FONT_NAME, size=9, italic=True, color=NEUTRAL_600)
r += 2
ws.cell(row=r, column=2, value="Notes").font = Font(name=base.FONT_NAME, size=12, bold=True, color=PRIMARY)
r += 1
notes = [
    "Fees, meals, hours, enrolment and subsidy fields are historical (2015 DSD survey) - confirm directly with centres.",
    "Verification levels: Registered = DSD/DBE registration on record; Owner-Claimed / Verified-Pro require owner verification.",
    "OpenStreetMap data is ODbL licensed; government datasets are public open data.",
    "To reach the full 42,420 ECD Census 2021 universe, register free at DataFirst (UCT) and import 'ecdcc-2021-public' via scripts/etl_preschools.py.",
]
for n_ in notes:
    ws.cell(row=r, column=2, value="- " + n_).font = Font(name=base.FONT_NAME, size=9, color=NEUTRAL_600)
    r += 1

for col, w in zip("BCDEFG", [38, 12, 12, 12, 12, 16]):
    ws.column_dimensions[col].width = w

# ============================================================ Sheet 2: City Coverage
ws2 = wb.create_sheet("City Coverage")
ws2.sheet_view.showGridLines = False
ws2["B2"] = "City & Town Coverage"
ws2["B2"].font = Font(name=base.FONT_NAME, size=14, bold=True, color=PRIMARY)
city_counts = Counter((x["province"], x["city"]) for x in DATA)
rows = sorted(city_counts.items(), key=lambda kv: -kv[1])
hdr = ["Province", "City / Town", "Centres"]
for c, h in enumerate(hdr, 2):
    cell = ws2.cell(row=4, column=c, value=h)
    cell.font = Font(name=base.FONT_NAME, size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=PRIMARY)
r = 5
for (prov, city), cnt in rows[:800]:
    ws2.cell(row=r, column=2, value=prov).font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
    ws2.cell(row=r, column=3, value=city).font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
    cell = ws2.cell(row=r, column=4, value=cnt)
    cell.font = Font(name=base.FONT_NAME, size=10, color=NEUTRAL_900)
    cell.number_format = "#,##0"
    if (r - 5) % 2 == 1:
        for c in range(2, 5):
            ws2.cell(row=r, column=c).fill = PatternFill("solid", fgColor=NEUTRAL_100)
    r += 1
for col, w in zip("BCD", [20, 34, 11]):
    ws2.column_dimensions[col].width = w

# ============================================================ Sheet 3: All Centres (write-optimized)
ws3 = wb.create_sheet("All Centres")
ws3.sheet_view.showGridLines = False
COLUMNS = [
    ("slug", "Slug"), ("name", "Centre Name"), ("province", "Province"), ("city", "City/Town"),
    ("suburb", "Suburb"), ("district", "District"), ("lat", "Latitude"), ("lon", "Longitude"),
    ("phone", "Phone"), ("email", "Email"), ("website", "Website"), ("address", "Address"),
    ("verificationStatus", "Verification"), ("registrationStatus", "Registration"),
    ("emis", "EMIS No."), ("mealsProvided", "Meals"), ("mealsDetail", "Meals Detail"),
    ("monthlyFeeMin", "Fee Min (R/mo)"), ("monthlyFeeMax", "Fee Max (R/mo)"),
    ("openingTime", "Opens"), ("closingTime", "Closes"), ("operatingModel", "Schedule"),
    ("subsidiesAccepted", "Subsidy"), ("totalChildren", "Enrolled"),
    ("siteType", "Site Type"), ("curriculum", "Curriculum"),
    ("dataCompleteness", "Completeness /12"), ("sources", "Sources"),
]
ws3.cell(row=2, column=2, value=f"All Centres ({len(DATA):,} records)").font = Font(name=base.FONT_NAME, size=14, bold=True, color=PRIMARY)
for c, (key, h) in enumerate(COLUMNS, 2):
    cell = ws3.cell(row=4, column=c, value=h)
    cell.font = Font(name=base.FONT_NAME, size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor=PRIMARY)
r = 5
for x in DATA:
    for c, (key, h) in enumerate(COLUMNS, 2):
        v = x.get(key)
        if key == "sources":
            v = "; ".join(SOURCE_LABELS.get(s, s) for s in v)
        if isinstance(v, bool):
            v = "Yes" if v else "No"
        if v is None:
            v = ""
        cell = ws3.cell(row=r, column=c, value=v)
        cell.font = Font(name=base.FONT_NAME, size=9, color=NEUTRAL_900)
        if key in ("monthlyFeeMin", "monthlyFeeMax", "totalChildren", "dataCompleteness") and v != "":
            cell.number_format = "#,##0"
    r += 1
widths = {"slug": 30, "name": 34, "province": 14, "city": 16, "suburb": 16, "district": 16,
          "lat": 10, "lon": 10, "phone": 14, "email": 22, "website": 22, "address": 26,
          "verificationStatus": 14, "registrationStatus": 22, "emis": 12, "mealsProvided": 8,
          "mealsDetail": 26, "monthlyFeeMin": 12, "monthlyFeeMax": 12, "openingTime": 8,
          "closingTime": 8, "operatingModel": 18, "subsidiesAccepted": 9, "totalChildren": 10,
          "siteType": 14, "curriculum": 14, "dataCompleteness": 13, "sources": 36}
for c, (key, h) in enumerate(COLUMNS, 2):
    ws3.column_dimensions[get_column_letter(c)].width = widths.get(key, 14)

# freeze panes on data sheet
ws3.freeze_panes = "B5"

wb.properties.creator = "Z.ai"
wb.save(OUT)
print(f"Saved {OUT}")
print(f"Sheets: {wb.sheetnames}")
print(f"All Centres rows: {r - 5}")
